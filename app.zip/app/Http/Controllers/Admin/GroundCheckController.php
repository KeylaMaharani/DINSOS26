<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GcJawaban;
use App\Models\GcKeterampilan;
use App\Models\GcKriteriaParameter;
use App\Models\GcLapanganUsaha;
use App\Models\GcPbiJawaban;
use App\Models\GcPenyakitKronis;
use App\Models\GcSasaran;
use App\Models\GcVerifikasi;
use App\Models\PbiApbd;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

/**
 * Alur entry Ground Check 2026 (mengikuti Panduan Entry Data SOLID):
 *  daftar sasaran (SATU BARIS PER KK) -> klik Detail -> daftar anggota KK -> klik pensil (Form Verifikasi Data)
 *  -> pilih status -> bila Ditemukan: form tab A-G -> centang pernyataan -> Submit.
 *
 * Draft: setiap saat petugas bisa menekan "Simpan Draft". Validasi wajib TIDAK dijalankan,
 * semua jawaban yang sudah terisi disimpan, dan terisi otomatis saat form dibuka lagi.
 * Kewajiban semua field baru ditegakkan saat Submit.
 *
 * Jawaban yang sudah diisi warga di halaman masyarakat (tabel pbi_apbd_gc_jawabans)
 * otomatis menjadi isian awal form petugas selama petugas belum menyimpan jawaban apa pun.
 *
 * CATATAN: flag "aktif" di Master GC hanya mengatur tampilan di halaman MASYARAKAT.
 * Form petugas ini selalu memuat SEMUA parameter & SEMUA opsi master.
 */
class GroundCheckController extends Controller
{
    private const TAHUN = 2026;

    /** Langkah 3: daftar sasaran (1 baris = 1 KK) + ringkasan (dengan filter tahun & rentang tanggal). */
    public function index(Request $request)
    {
        $q = trim((string) $request->query('q'));
        $perPage = in_array((int) $request->query('per_page'), [10, 25, 50], true) ? (int) $request->query('per_page') : 10;

        // Filter tahun & tanggal = waktu masyarakat MENGIRIM PENGAJUAN (tabel pbi_apbds.created_at),
        // dihubungkan ke sasaran lewat No KK. Badge/progres/ringkasan tetap memakai tahun Ground Check.
        $tahunPilih = $request->query('tahun');
        $tahunPilih = ctype_digit((string) $tahunPilih) ? (int) $tahunPilih : null;
        $tglDari = $request->query('tgl_dari') ?: null;
        $tglSampai = $request->query('tgl_sampai') ?: null;
        $tahun = self::TAHUN;

        $adaFilterPengajuan = $tahunPilih || $tglDari || $tglSampai;

        // Syarat pengajuan (dipakai bersama oleh daftar dan kartu ringkasan).
        $filterPengajuan = function ($s) use ($tahunPilih, $tglDari, $tglSampai) {
            $s->whereExists(function ($e) use ($tahunPilih, $tglDari, $tglSampai) {
                $e->select(DB::raw(1))
                    ->from('pbi_apbds as p')
                    ->whereRaw('TRIM(p.no_kk) = TRIM(gc_sasarans.no_kk)')
                    ->when($tahunPilih, fn ($x) => $x->whereYear('p.created_at', $tahunPilih))
                    ->when($tglDari, fn ($x) => $x->whereDate('p.created_at', '>=', $tglDari))
                    ->when($tglSampai, fn ($x) => $x->whereDate('p.created_at', '<=', $tglSampai));
            });
        };

        $sasarans = GcSasaran::query()
            ->select('gc_sasarans.*')
            ->selectSub(function ($s) {
                $s->from('gc_sasarans as m')->selectRaw('count(*)')->whereColumn('m.no_kk', 'gc_sasarans.no_kk');
            }, 'kk_total')
            ->selectSub(function ($s) use ($tahun) {
                $s->from('gc_sasarans as m')
                    ->join('gc_verifikasis as v', 'v.sasaran_id', '=', 'm.id')
                    ->selectRaw('count(*)')
                    ->whereColumn('m.no_kk', 'gc_sasarans.no_kk')
                    ->where('v.tahun', $tahun)
                    ->where('v.status_entry', 'submit');
            }, 'kk_selesai')
            ->with(['verifikasis' => fn ($v) => $v->where('tahun', $tahun)])
            // SATU BARIS PER KK: wakil keluarga = anggota yang NIK-nya sama dengan kepala keluarga
            // pada pengajuan masyarakat; kalau tidak ada, anggota dengan id terkecil.
            ->whereRaw('gc_sasarans.id = (
                select m2.id from gc_sasarans m2
                left join pbi_apbds p2
                    on TRIM(p2.no_kk) = m2.no_kk and TRIM(p2.nik_kepala_keluarga) = m2.nik
                where m2.no_kk = gc_sasarans.no_kk
                order by case when p2.id is null then 1 else 0 end, m2.id
                limit 1
            )')
            // Filter tahun & tanggal pengajuan: hanya sasaran yang No KK-nya punya pengajuan
            // masyarakat sesuai (tahun & rentang tanggal dicek pada satu pengajuan yang sama).
            ->when($adaFilterPengajuan, $filterPengajuan)
            // Pencarian mencocokkan SEMUA anggota KK (mencari "Siti" tetap memunculkan keluarganya).
            ->when($q !== '', function ($s) use ($q) {
                $like = "%{$q}%";
                $s->where(function ($w) use ($like) {
                    $w->where('gc_sasarans.no_kk', 'like', $like)
                        ->orWhereIn('gc_sasarans.no_kk', function ($x) use ($like) {
                            $x->from('gc_sasarans as a')->select('a.no_kk')
                                ->where(fn ($y) => $y->where('a.nama', 'like', $like)->orWhere('a.nik', 'like', $like));
                        });
                });
            })
            ->orderBy('kelurahan')->orderBy('no_kk')->orderBy('nama')
            ->paginate($perPage)
            ->withQueryString();

        // Kartu ringkasan mengikuti filter tahun/tanggal (tanpa pencarian nama), dihitung per orang.
        $basis = GcSasaran::query()->when($adaFilterPengajuan, $filterPengajuan);
        $total = (clone $basis)->count();
        $sudah = (clone $basis)
            ->whereHas('verifikasis', fn ($v) => $v->where('tahun', $tahun)->where('status_entry', 'submit'))
            ->count();
        $belum = max($total - $sudah, 0);
        $progres = $total > 0 ? round($sudah / $total * 100, 1) : 0;

        // Daftar tahun untuk dropdown: tahun pengajuan yang ada + 2024 sampai tahun ini.
        $tahunList = DB::table('pbi_apbds')
            ->selectRaw('YEAR(created_at) as th')
            ->whereNotNull('created_at')
            ->distinct()
            ->pluck('th')
            ->map(fn ($t) => (int) $t)
            ->merge(range((int) now()->year, 2024))
            ->unique()->sortDesc()->values();

        // Saran isian untuk form Tambah (diambil dari wilayah yang sudah ada di daftar sasaran).
        $kecamatanList = GcSasaran::whereNotNull('kecamatan')->distinct()->orderBy('kecamatan')->pluck('kecamatan');
        $kelurahanList = GcSasaran::whereNotNull('kelurahan')->distinct()->orderBy('kelurahan')->pluck('kelurahan');

        return view('admin.ground-check.index', compact(
            'sasarans', 'total', 'sudah', 'belum', 'progres', 'q', 'perPage',
            'kecamatanList', 'kelurahanList', 'tahunList', 'tahun'
        ));
    }

    /**
     * TAMBAH sasaran baru ke Daftar Sasaran Ground Check.
     * Bila No KK sudah ada, orang ini otomatis menjadi anggota KK tersebut dan
     * wilayah/alamat/desil yang dikosongkan diambil dari anggota KK yang sudah ada.
     */
    public function store(Request $request)
    {
        $data = $request->validateWithBag('tambah', [
            'nik' => ['required', 'digits:16', 'unique:gc_sasarans,nik'],
            'nama' => ['required', 'string', 'max:255'],
            'no_kk' => ['required', 'digits:16'],
            'tanggal_lahir' => ['nullable', 'date', 'before_or_equal:today'],
            'kecamatan' => ['nullable', 'string', 'max:255'],
            'kelurahan' => ['nullable', 'string', 'max:255'],
            'alamat' => ['nullable', 'string', 'max:1000'],
            'rt' => ['nullable', 'string', 'max:5'],
            'rw' => ['nullable', 'string', 'max:5'],
            'desil' => ['nullable', 'integer', 'between:1,10'],
        ], [
            'nik.required' => 'NIK wajib diisi.',
            'nik.digits' => 'NIK harus 16 digit angka.',
            'nik.unique' => 'NIK sudah terdaftar di Daftar Sasaran.',
            'nama.required' => 'Nama wajib diisi.',
            'no_kk.required' => 'No KK wajib diisi.',
            'no_kk.digits' => 'No KK harus 16 digit angka.',
            'tanggal_lahir.date' => 'Tanggal lahir tidak valid.',
            'tanggal_lahir.before_or_equal' => 'Tanggal lahir tidak boleh melebihi hari ini.',
            'desil.integer' => 'Desil harus berupa angka.',
            'desil.between' => 'Desil harus antara 1 sampai 10.',
        ]);

        $data['nama'] = Str::upper(trim($data['nama']));

        // Anggota KK yang sudah ada -> lengkapi data wilayah yang kosong.
        $anggotaLama = GcSasaran::where('no_kk', $data['no_kk'])->first();
        if ($anggotaLama) {
            foreach (['kecamatan', 'kelurahan', 'alamat', 'rt', 'rw', 'desil'] as $f) {
                if (blank($data[$f] ?? null)) {
                    $data[$f] = $anggotaLama->{$f};
                }
            }
        }

        $sasaran = GcSasaran::create($data);

        return redirect()->route('ground-check.keluarga', $sasaran->no_kk)
            ->with('success', $sasaran->nama . ' berhasil ditambahkan ke Daftar Sasaran. Klik ikon pensil untuk mulai mengisi data.');
    }

    /** Langkah 5: anggota satu KK (kepala keluarga ditampilkan paling atas). */
    public function keluarga(string $noKk)
    {
        $tahun = self::TAHUN;

        // Kepala keluarga menurut pengajuan masyarakat (kalau ada).
        $kepalaNik = trim((string) DB::table('pbi_apbds')
            ->whereRaw('TRIM(no_kk) = ?', [$noKk])
            ->orderByDesc('id')
            ->value('nik_kepala_keluarga'));

        $anggota = GcSasaran::where('no_kk', $noKk)
            ->with(['verifikasis' => fn ($v) => $v->where('tahun', $tahun)])
            ->get()
            ->sortBy(fn ($a) => ($a->nik === $kepalaNik ? '0' : '1') . Str::lower((string) $a->nama))
            ->values();

        abort_if($anggota->isEmpty(), 404);

        return view('admin.ground-check.keluarga', compact('noKk', 'anggota', 'kepalaNik'));
    }

    /** Langkah 6: simpan status (Form Verifikasi Data). */
    public function statusStore(Request $request, GcSasaran $sasaran)
    {
        $data = $request->validate([
            'status_temuan' => ['required', Rule::in(array_keys(GcVerifikasi::STATUS_TEMUAN))],
        ], [
            'status_temuan.required' => 'Status wajib dipilih.',
            'status_temuan.in' => 'Status tidak valid.',
        ]);

        $v = GcVerifikasi::firstOrNew(['sasaran_id' => $sasaran->id, 'tahun' => self::TAHUN]);
        $sebelumnya = $v->status_temuan;

        $v->status_temuan = $data['status_temuan'];
        $v->user_id = Auth::id();

        if ($data['status_temuan'] === 'ditemukan') {
            // Baru ditemukan (atau sebelumnya pindah/meninggal): mulai ulang sebagai draf.
            if (! $v->exists || $sebelumnya !== 'ditemukan') {
                $v->status_entry = 'draft';
                $v->submitted_at = null;
                $v->pernyataan = false;
            }
        } else {
            // Pindah/Tidak Ditemukan/Meninggal: tidak ada form lanjutan, langsung selesai.
            $v->status_entry = 'submit';
            $v->submitted_at = now();
            $v->pernyataan = false;
        }

        $v->save();

        if ($data['status_temuan'] === 'ditemukan') {
            return redirect()->route('ground-check.form', $sasaran);
        }

        return redirect()->route('ground-check.keluarga', $sasaran->no_kk)
            ->with('success', 'Status ' . $sasaran->nama . ' disimpan: ' . GcVerifikasi::STATUS_TEMUAN[$data['status_temuan']] . '.');
    }

    /** Langkah 7-13: form tab A-G. */
    public function form(Request $request, GcSasaran $sasaran)
    {
        $v = $this->verifikasiDitemukan($sasaran);
        if (! $v) {
            return redirect()->route('ground-check.keluarga', $sasaran->no_kk)
                ->with('error', 'Pilih status "Ditemukan" terlebih dahulu sebelum mengisi form.');
        }

        // Petugas melihat SEMUA parameter (flag aktif hanya untuk halaman masyarakat).
        $params = GcKriteriaParameter::untukPetugas()->with('opsis')->get();
        $master = $this->masterKetenagakerjaan();

        $tabs = [];
        foreach (GcKriteriaParameter::TAB as $key => $tab) {
            $isi = $params->whereIn('kelompok', $tab['kelompok'])->values();
            if ($isi->isNotEmpty()) {
                $tabs[] = $tab + ['key' => $key, 'params' => $isi];
            }
        }

        // Hanya jawaban yang benar-benar terisi (draf yang berisi null/kosong tidak dihitung).
        $tersimpan = [];
        foreach ($v->jawabans()->get() as $j) {
            if ($j->parameter_id && $j->jawaban !== null && $j->jawaban !== '') {
                $tersimpan[$j->parameter_id] = $j->jawaban;
            }
        }

        // Prefill (identitas, jawaban warga, data keluarga) hanya bila belum ada satu pun jawaban tersimpan.
        $nilai = $tersimpan ?: $this->prefill($sasaran, $params);

        // Pertanyaan pemicu di tab Ketenagakerjaan + daftar field yang bergantung padanya.
        $gate = $this->gateKerja($params);
        $kerja = $gate ? [
            'gate' => $gate->id,
            'dependen' => $params->where('kelompok', 'ketenagakerjaan')
                ->where('id', '!=', $gate->id)->pluck('id')->values()->all(),
        ] : null;

        // Badge progres tab mengikuti isian yang tampil (termasuk hasil prefill).
        $terisi = array_filter($nilai, fn ($x) => $x !== null && $x !== '');
        $statusTab = $this->statusTab($tabs, $terisi, $kerja);

        $tabAwal = (int) session('tab', 0);

        return view('admin.ground-check.form', compact(
            'sasaran', 'v', 'tabs', 'nilai', 'tabAwal', 'master', 'kerja', 'statusTab'
        ));
    }

    /** Simpan draf / submit. Saat submit, semua isian wajib diisi. */
    public function simpan(Request $request, GcSasaran $sasaran)
    {
        $v = $this->verifikasiDitemukan($sasaran);
        abort_if(! $v, 403);

        $submit = $request->input('aksi') === 'submit';
        $params = GcKriteriaParameter::untukPetugas()->with('opsis')->get();
        $existing = $v->jawabans()->get()->keyBy('parameter_id');
        $master = $this->masterKetenagakerjaan();
        $lapParam = $params->firstWhere('sumber', 'lapangan_usaha');

        // Field Ketenagakerjaan lain hanya berlaku jika responden bekerja ("Ya").
        $gate = $this->gateKerja($params);
        $bekerja = $gate && $request->input("jawaban.{$gate->id}") === 'Ya';
        $dependenIds = $gate
            ? $params->where('kelompok', 'ketenagakerjaan')->where('id', '!=', $gate->id)->pluck('id')->all()
            : [];

        $rules = [];
        $attributes = [];

        foreach ($params as $p) {
            $key = "jawaban.{$p->id}";
            $attributes[$key] = $p->nama;

            // Responden tidak bekerja -> field turunan tidak diwajibkan & akan dikosongkan.
            if (in_array($p->id, $dependenIds, true) && ! $bekerja) {
                $rules[$key] = ['nullable'];
                continue;
            }

            $req = $submit ? 'required' : 'nullable';
            $labels = $this->labelOpsi($p, $master);

            switch ($p->tipe_input) {
                case 'pilihan':
                    $rules[$key] = $labels
                        ? [$req, 'string', Rule::in($labels)]
                        : [$req, 'string', 'max:500'];
                    break;

                case 'pilihan_ganda':
                    // Tanpa opsi di master tidak ada yang bisa dipilih, jadi tidak diwajibkan.
                    $rules[$key] = $submit && $labels ? ['required', 'array', 'min:1'] : ['nullable', 'array'];
                    $rules["{$key}.*"] = $labels ? ['string', Rule::in($labels)] : ['string', 'max:255'];
                    $attributes["{$key}.*"] = $p->nama;
                    break;

                case 'angka':
                    $rules[$key] = $this->koordinatAngka($p)
                        ? [$req, 'numeric']
                        : [$req, 'numeric', 'min:0'];
                    break;

                case 'tanggal':
                    $rules[$key] = [$req, 'date'];
                    break;

                case 'koordinat':
                    $rules[$key] = [$req, 'string', 'max:100'];
                    break;

                case 'foto':
                    $sudahAda = ! empty(optional($existing->get($p->id))->jawaban);
                    $rules[$key] = [$submit && ! $sudahAda ? 'required' : 'nullable', 'image', 'max:5120'];
                    break;

                default: // teks
                    $rules[$key] = [$req, 'string', 'max:500'];
            }

            // Keterampilan bertanda eksklusif (mis. "Belum Ada") tidak boleh digabung dengan pilihan lain.
            if ($p->sumber === 'keterampilan') {
                $eksklusif = $master['keterampilan']->where('eksklusif', true)->pluck('nama')->all();
                $rules[$key][] = function ($attr, $value, $fail) use ($eksklusif) {
                    if (! is_array($value) || count($value) < 2) {
                        return;
                    }
                    $bentrok = array_intersect($value, $eksklusif);
                    if ($bentrok) {
                        $fail('Pilihan "' . implode('", "', $bentrok) . '" tidak boleh digabung dengan pilihan lain.');
                    }
                };
            }

            // Pekerjaan harus termasuk dalam lapangan usaha yang dipilih.
            if ($p->sumber === 'pekerjaan' && $lapParam) {
                $rules[$key][] = function ($attr, $value, $fail) use ($request, $lapParam, $master) {
                    if ($value === null || $value === '') {
                        return;
                    }
                    $lap = $master['lapangan']->firstWhere('nama', $request->input("jawaban.{$lapParam->id}"));
                    if (! $lap || ! $lap->pekerjaans->contains('nama', $value)) {
                        $fail('Pekerjaan tidak sesuai dengan lapangan usaha yang dipilih.');
                    }
                };
            }
        }

        if ($submit) {
            $rules['pernyataan'] = ['accepted'];
        }

        $request->validate($rules, [
            'required' => ':attribute wajib diisi.',
            'in' => 'Pilihan pada :attribute tidak valid.',
            'numeric' => ':attribute harus berupa angka.',
            'min.numeric' => ':attribute tidak boleh negatif.',
            'min.array' => 'Pilih minimal satu jawaban untuk :attribute.',
            'image' => ':attribute harus berupa gambar.',
            'max.file' => ':attribute maksimal 5 MB.',
            'date' => ':attribute bukan tanggal yang valid.',
            'accepted' => 'Centang pernyataan kebenaran data terlebih dahulu.',
        ], $attributes);

        DB::transaction(function () use ($request, $params, $existing, $v, $submit, $bekerja, $dependenIds) {
            foreach ($params as $p) {
                $row = $existing->get($p->id) ?? new GcJawaban(['verifikasi_id' => $v->id, 'parameter_id' => $p->id]);

                // Responden tidak bekerja -> jawaban field turunan dikosongkan.
                $kosongkan = in_array($p->id, $dependenIds, true) && ! $bekerja;
                $input = $kosongkan ? null : $request->input("jawaban.{$p->id}");
                $jawaban = null;
                $skor = null;

                switch ($p->tipe_input) {
                    case 'pilihan':
                        $jawaban = ($input === null || $input === '') ? null : (string) $input;
                        $skor = $jawaban !== null ? optional($p->opsis->firstWhere('label', $jawaban))->nilai : null;
                        break;

                    case 'pilihan_ganda':
                        $arr = array_values(array_filter((array) $input, fn ($x) => $x !== null && $x !== ''));
                        $jawaban = $arr ? json_encode($arr, JSON_UNESCAPED_UNICODE) : null;
                        break;

                    case 'foto':
                        $jawaban = $row->jawaban;
                        if ($request->hasFile("jawaban.{$p->id}")) {
                            if ($jawaban) {
                                Storage::disk('public')->delete($jawaban);
                            }
                            $jawaban = $request->file("jawaban.{$p->id}")->store("ground-check/{$v->id}", 'public');
                        }
                        break;

                    default:
                        $jawaban = ($input === null || $input === '') ? null : (string) $input;
                }

                $row->fill([
                    'nama_parameter' => $p->nama,
                    'bobot' => $p->bobot,
                    'jawaban' => $jawaban,
                    'skor' => $skor,
                ])->save();
            }

            $v->pernyataan = $submit;
            $v->status_entry = $submit ? 'submit' : 'draft';
            $v->submitted_at = $submit ? now() : null;
            $v->user_id = Auth::id();
            $v->save();
        });

        if ($submit) {
            return redirect()->route('ground-check.keluarga', $sasaran->no_kk)
                ->with('success', 'Data ' . $sasaran->nama . ' berhasil disubmit.');
        }

        return redirect()->route('ground-check.form', $sasaran)
            ->with('success', 'Draf tersimpan. Kamu bisa melanjutkan kapan saja.')
            ->with('tab', (int) $request->input('tab_aktif', 0));
    }

    private function verifikasiDitemukan(GcSasaran $sasaran): ?GcVerifikasi
    {
        return GcVerifikasi::where('sasaran_id', $sasaran->id)
            ->where('tahun', self::TAHUN)
            ->where('status_temuan', 'ditemukan')
            ->first();
    }

    private function koordinatAngka(GcKriteriaParameter $p): bool
    {
        return Str::contains(Str::lower($p->nama), ['lintang', 'bujur']);
    }

    /** Pertanyaan pemicu di tab Ketenagakerjaan ("Apakah responden bekerja ... seminggu yang lalu?"). */
    private function gateKerja($params): ?GcKriteriaParameter
    {
        return $params->first(fn ($p) => $p->kelompok === 'ketenagakerjaan'
            && Str::startsWith(Str::lower(trim($p->nama)), 'apakah responden bekerja'));
    }

    /**
     * Progres tiap tab dari jawaban yang terisi: kosong | draft | lengkap.
     * Field Ketenagakerjaan turunan tidak dihitung bila responden tidak bekerja.
     */
    private function statusTab(array $tabs, array $tersimpan, ?array $kerja): array
    {
        $bekerja = $kerja && (($tersimpan[$kerja['gate']] ?? null) === 'Ya');
        $hasil = [];

        foreach ($tabs as $i => $t) {
            $total = 0;
            $isi = 0;

            foreach ($t['params'] as $p) {
                if ($kerja && ! $bekerja && in_array($p->id, $kerja['dependen'], true)) {
                    continue;
                }
                // Pilihan ganda tanpa opsi tidak bisa diisi -> tidak dihitung.
                if ($p->tipe_input === 'pilihan_ganda' && ! $p->sumber && $p->opsis->isEmpty()) {
                    continue;
                }

                $total++;
                if (isset($tersimpan[$p->id])) {
                    $isi++;
                }
            }

            $hasil[$i] = [
                'isi' => $isi,
                'total' => $total,
                'status' => ($total === 0 || $isi >= $total) ? 'lengkap' : ($isi === 0 ? 'kosong' : 'draft'),
            ];
        }

        return $hasil;
    }

    /** Data master untuk petugas: SEMUA data (aktif maupun disembunyikan dari masyarakat). */
    private function masterKetenagakerjaan(): array
    {
        return [
            'lapangan' => GcLapanganUsaha::orderBy('urutan')->orderBy('id')->with('pekerjaans')->get(),
            'keterampilan' => GcKeterampilan::orderBy('urutan')->orderBy('id')->get(),
            'penyakit' => GcPenyakitKronis::orderBy('urutan')->orderBy('id')->get(),
        ];
    }

    /** Daftar jawaban yang sah untuk sebuah parameter (dari master atau dari opsi). */
    private function labelOpsi(GcKriteriaParameter $p, array $master): array
    {
        return match ($p->sumber) {
            'lapangan_usaha' => $master['lapangan']->pluck('nama')->all(),
            'pekerjaan' => $master['lapangan']->flatMap(fn ($l) => $l->pekerjaans->pluck('nama'))->unique()->values()->all(),
            'keterampilan' => $master['keterampilan']->pluck('nama')->all(),
            'penyakit_kronis' => $master['penyakit']->pluck('nama')->all(),
            default => $p->opsis->pluck('label')->all(),
        };
    }

    /** Pengajuan PBI APBD terbaru milik No KK sasaran ini (sumber jawaban warga). */
    private function pbiSasaran(GcSasaran $sasaran): ?PbiApbd
    {
        return PbiApbd::whereRaw('TRIM(no_kk) = ?', [$sasaran->no_kk])->latest('id')->first();
    }

    /**
     * Isian awal form petugas, berurutan (yang belakangan menimpa yang depan):
     *  1. data identitas dari daftar sasaran;
     *  2. jawaban warga di halaman masyarakat (pbi_apbd_gc_jawabans):
     *     - kepala keluarga -> semua jawaban (foto dilewati);
     *     - anggota lain    -> hanya kelompok Keluarga & Aset (data milik satu KK);
     *  3. isian Keluarga/Aset dari anggota satu KK yang sudah disubmit petugas.
     */
    private function prefill(GcSasaran $sasaran, $params): array
    {
        $nilai = [];

        $identitas = [
            'nama' => $sasaran->nama,
            'no kk' => $sasaran->no_kk,
            'alamat' => $sasaran->alamat,
            'tanggal lahir' => optional($sasaran->tanggal_lahir)->format('Y-m-d'),
        ];
        foreach ($params as $p) {
            $nama = Str::lower(trim($p->nama));
            if (array_key_exists($nama, $identitas) && $identitas[$nama] !== null) {
                $nilai[$p->id] = $identitas[$nama];
            }
        }

        $kelompokKeluarga = ['keluarga', 'aset_bergerak', 'aset_tidak_bergerak'];

        // 2. Jawaban warga
        $pbi = $this->pbiSasaran($sasaran);
        if ($pbi) {
            $kepala = trim((string) $pbi->nik_kepala_keluarga) === (string) $sasaran->nik;
            $idBoleh = $params->where('tipe_input', '!=', 'foto')->pluck('id')->all();
            $idKeluarga = $params->whereIn('kelompok', $kelompokKeluarga)->pluck('id')->all();

            $jawabanWarga = GcPbiJawaban::where('pbi_apbd_id', $pbi->id)
                ->whereNotNull('parameter_id')
                ->whereNotNull('jawaban')
                ->where('jawaban', '!=', '')
                ->get();

            foreach ($jawabanWarga as $j) {
                if (! in_array($j->parameter_id, $idBoleh, true)) {
                    continue;
                }
                if (! $kepala && ! in_array($j->parameter_id, $idKeluarga, true)) {
                    continue;
                }
                $nilai[$j->parameter_id] = $j->jawaban;
            }
        }

        // 3. Anggota KK lain yang sudah disubmit petugas
        $sumber = GcVerifikasi::where('tahun', self::TAHUN)
            ->where('status_entry', 'submit')
            ->where('status_temuan', 'ditemukan')
            ->whereHas('sasaran', fn ($s) => $s->where('no_kk', $sasaran->no_kk)->where('id', '!=', $sasaran->id))
            ->latest('submitted_at')
            ->first();

        if ($sumber) {
            $idKeluarga = $params->whereIn('kelompok', $kelompokKeluarga)->pluck('id')->all();
            foreach ($sumber->jawabans()->whereIn('parameter_id', $idKeluarga)->get() as $j) {
                if ($j->jawaban !== null) {
                    $nilai[$j->parameter_id] = $j->jawaban;
                }
            }
        }

        return $nilai;
    }
}