<?php

namespace App\Http\Controllers;

use App\Models\DtsenPermohonan;
use App\Models\GcLapanganUsaha;
use App\Models\PbiApbd;
use App\Models\PbiApbdLog;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class RegistrasiController extends Controller
{
    /** GET /registrasi/step-1 */
    public function step1(Request $request)
    {
        $a = random_int(1, 9);
        $b = random_int(1, 9);
        $request->session()->put('reg_captcha_a', $a);
        $request->session()->put('reg_captcha_b', $b);

        return view('registrasi.step1', ['captchaA' => $a, 'captchaB' => $b]);
    }

    /** POST /registrasi/step-1 */
    public function step1Store(Request $request)
    {
        $expected = (int) $request->session()->get('reg_captcha_a', 0)
            + (int) $request->session()->get('reg_captcha_b', 0);

        $validated = $request->validate([
            'no_kk' => ['required', 'digits:16'],
            'captcha' => ['required', 'numeric'],
        ]);

        if ((int) $validated['captcha'] !== $expected) {
            throw ValidationException::withMessages([
                'captcha' => 'Jawaban verifikasi salah, silakan coba lagi.',
            ]);
        }

        $request->session()->forget(['reg_captcha_a', 'reg_captcha_b']);
        $request->session()->put('registrasi.no_kk', $validated['no_kk']);

        return redirect()->route('registrasi.step2');
    }

    /** GET /registrasi/step-2 */
    public function step2(Request $request)
    {
        $noKk = $request->session()->get('registrasi.no_kk');

        if (! $noKk) {
            return redirect()->route('registrasi.step1')
                ->with('error', 'Silakan masukan No KK terlebih dahulu.');
        }

        // Master lapangan usaha + pekerjaan (beserta penjelasan/contoh) untuk pilihan Pekerjaan
        $lapangan = $this->lapanganAktif()
            ->map(fn ($l) => [
                'nama' => $l->nama,
                'penjelasan' => $l->penjelasan,
                'sendiri' => $l->contoh_berusaha_sendiri,
                'buruh' => $l->contoh_buruh,
                'pekerjaan' => $l->pekerjaansAktif->pluck('nama')->values()->all(),
            ])
            ->filter(fn ($l) => count($l['pekerjaan']) > 0)
            ->values()
            ->all();

        return view('registrasi.step2', [
            'noKk' => $noKk,
            // Peta kecamatan => daftar kelurahan (config/wilayah.php) untuk dropdown berantai
            'wilayah' => config('wilayah.kecamatan', []),
            'lapangan' => $lapangan,
        ]);
    }

    /** POST /registrasi/step-2 */
    public function step2Store(Request $request)
    {
        $noKk = $request->session()->get('registrasi.no_kk');

        if (! $noKk) {
            return redirect()->route('registrasi.step1')
                ->with('error', 'Sesi pendaftaran sudah habis, silakan mulai ulang dari Step 1.');
        }

        // Samakan penulisan dengan config/wilayah.php (huruf besar) sebelum divalidasi
        $request->merge([
            'kecamatan' => strtoupper(trim((string) $request->input('kecamatan'))),
            'desa_kelurahan' => strtoupper(trim((string) $request->input('desa_kelurahan'))),
        ]);

        $wilayah = config('wilayah.kecamatan', []);
        $daftarPekerjaan = $this->daftarPekerjaan();

        $validated = $request->validate([
            'status_hubungan' => ['required', Rule::in(['kepala_keluarga', 'suami', 'istri', 'anak', 'lainnya'])],
            'nik' => ['required', 'digits:16', Rule::unique('pbi_apbds', 'nik_kepala_keluarga')],
            'password' => [
                'required', 'string', 'min:8', 'confirmed',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).+$/',
            ],
            'alamat' => ['required', 'string'],
            'rt' => ['nullable', 'string', 'max:5'],
            'rw' => ['nullable', 'string', 'max:5'],
            'provinsi' => ['required', 'string'],
            'kab_kota' => ['required', 'string'],
            'kecamatan' => ['required', 'string', Rule::in(array_keys($wilayah))],
            'desa_kelurahan' => ['required', 'string', function ($attr, $value, $fail) use ($request, $wilayah) {
                if (! in_array($value, $wilayah[$request->input('kecamatan')] ?? [], true)) {
                    $fail('Desa/Kelurahan tidak sesuai dengan kecamatan yang dipilih.');
                }
            }],
            'nama_lengkap' => ['required', 'string', 'max:150'],
            'email' => ['required', 'email', Rule::unique('users', 'email')],
            'telp' => ['required', 'string', 'max:20'],
            'agama' => ['required', 'string'],
            // Pekerjaan harus salah satu pekerjaan aktif di master (kalau master masih kosong, teks bebas diterima)
            'pekerjaan' => ['required', 'string', 'max:100', function ($attr, $value, $fail) use ($daftarPekerjaan) {
                if ($daftarPekerjaan->isNotEmpty() && ! $this->cariPekerjaan($daftarPekerjaan, (string) $value)) {
                    $fail('Pilih pekerjaan dari daftar yang tersedia.');
                }
            }],
            'tempat_lahir' => ['required', 'string'],
            'tgl_lahir' => ['required', 'date'],
            'jenis_kelamin' => ['required', Rule::in(['L', 'P'])],
            'anggota' => ['nullable', 'array'],
            'anggota.*.nama' => ['required_with:anggota', 'string', 'max:150'],
            'anggota.*.nik' => ['required_with:anggota', 'digits:16'],
            'anggota.*.status' => ['required_with:anggota', 'string'],
        ], [
            'password.regex' => 'Password minimal 8 karakter, memuat 1 huruf kapital, 1 huruf kecil, 1 angka, dan 1 karakter khusus (contoh: @ # $ ! %).',
            'nik.unique' => 'NIK ini sudah pernah mengajukan PBI APBD.',
            'email.unique' => 'Email ini sudah terdaftar, silakan login.',
            'kecamatan.in' => 'Kecamatan tidak valid.',
            'pekerjaan.required' => 'Pekerjaan wajib dipilih.',
        ]);

        // Simpan dengan penulisan persis seperti di master, supaya cocok saat dikunci di form Lengkapi Data
        $validated['pekerjaan'] = $this->cariPekerjaan($daftarPekerjaan, $validated['pekerjaan']) ?? $validated['pekerjaan'];

        $noRegistrasi = 'PBI-APBD-' . now()->year . '-'
            . Str::padLeft((string) (PbiApbd::whereYear('created_at', now()->year)->count() + 1), 4, '0');

        $masyarakatRole = Role::firstOrCreate(
            ['slug' => 'masyarakat'],
            ['name' => 'Masyarakat', 'slug' => 'masyarakat']
        );

        [$user, $pbiApbd] = DB::transaction(function () use ($validated, $noKk, $noRegistrasi, $masyarakatRole) {
            $user = User::create([
                'name' => $validated['nama_lengkap'],
                'username' => $validated['nik'],
                'email' => $validated['email'],
                'password' => Hash::make($validated['password']),
                'role_id' => $masyarakatRole->id,
            ]);

            // Tautkan pengajuan DTSEN yang sebelumnya dibuat petugas atas NIK ini
            // (saat itu warga belum punya akun, jadi user_id masih kosong).
            DtsenPermohonan::whereNull('user_id')
                ->whereHas('detail', fn ($q) => $q->where('nik', $user->username))
                ->update(['user_id' => $user->id]);

            $pbiApbd = PbiApbd::create([
                'user_id' => $user->id,
                'no_registrasi' => $noRegistrasi,
                'no_kk' => $noKk,
                'nama_kepala_keluarga' => $validated['nama_lengkap'],
                'nik_kepala_keluarga' => $validated['nik'],
                'alamat' => $validated['alamat'],
                'rt' => $validated['rt'] ?? null,
                'rw' => $validated['rw'] ?? null,
                'provinsi' => $validated['provinsi'],
                'kabupaten_kota' => $validated['kab_kota'],
                'kecamatan' => $validated['kecamatan'],
                'desa_kelurahan' => $validated['desa_kelurahan'],
                'no_telp' => $validated['telp'],
                'email' => $validated['email'],
                // Tahap awal alur = 'kelurahan' (lihat PbiApbd::STAGES).
                // Kolom `status` di migration default-nya 'operator_dinsos',
                // itu keliru/basi -- override eksplisit di sini.
                'status' => 'kelurahan',
            ]);

            $pbiApbd->anggotaKeluarga()->create([
                'nik' => $validated['nik'],
                'nama' => $validated['nama_lengkap'],
                'tempat_lahir' => $validated['tempat_lahir'],
                'tanggal_lahir' => $validated['tgl_lahir'],
                'pekerjaan' => $validated['pekerjaan'],
                'agama' => $validated['agama'],
                'jenis_kelamin' => $validated['jenis_kelamin'],
                'hubungan_keluarga' => $validated['status_hubungan'],
                'keanggotaan_bpjs' => 'Belum Terdaftar',
            ]);

            foreach ($validated['anggota'] ?? [] as $anggota) {
                $pbiApbd->anggotaKeluarga()->create([
                    'nik' => $anggota['nik'],
                    'nama' => $anggota['nama'],
                    'hubungan_keluarga' => $anggota['status'],
                ]);
            }

            // Catat riwayat awal supaya halaman Tracking tidak kosong sejak registrasi
            PbiApbdLog::create([
                'pbi_apbd_id' => $pbiApbd->id,
                'user_id' => $user->id,
                'username' => $user->name,
                'role_name' => 'Masyarakat',
                'task_name' => 'Registrasi akun & permohonan dibuat',
                'catatan' => null,
            ]);

            return [$user, $pbiApbd];
        });

        $request->session()->forget('registrasi.no_kk');

        return redirect()->route('login')->with('success', [
            'no_registrasi' => $pbiApbd->no_registrasi,
            'nama' => $pbiApbd->nama_kepala_keluarga,
        ]);
    }

    // ==========================================================
    // Master pekerjaan
    // ==========================================================

    private function lapanganAktif()
    {
        return GcLapanganUsaha::aktif()->with('pekerjaansAktif')->get();
    }

    /** Semua nama pekerjaan aktif di master (unik). */
    private function daftarPekerjaan()
    {
        return $this->lapanganAktif()
            ->flatMap(fn ($l) => $l->pekerjaansAktif->pluck('nama'))
            ->unique()
            ->values();
    }

    /** Cari nama pekerjaan di master tanpa peduli besar-kecil huruf; kembalikan penulisan master. */
    private function cariPekerjaan($daftar, string $nama): ?string
    {
        $t = Str::lower(trim($nama));

        return $t === '' ? null : $daftar->first(fn ($n) => Str::lower(trim($n)) === $t);
    }
}
