<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable(['name', 'slug', 'description', 'permissions'])]
class Role extends Model
{
    protected $casts = [
        'permissions' => 'array',
    ];

    /**
     * Daftar modul yang bisa dicentang di form "Kelola Hak Akses".
     * (Key lama TIDAK diubah, jadi hak akses role yang sudah tersimpan tetap berlaku.)
     */
    public const MODULES = [
        'beranda' => 'Beranda',

        // --- Portal (menu website; dulu bernama "Front End") ---
        'menu-frontend' => 'Portal - Kelola Menu Website',

        // --- PFM (Monitoring) ---
        'pbi-apbd' => 'PFM - PBI APBD (Super Admin: Ajuan, Arsip, Monitoring)',
        'kartu-kks' => 'PFM - Kartu KKS',
        'dtsen' => 'PFM - DTSEN',

        // --- PFM: halaman approval PBI APBD per tahap ---
        'pbi-operator' => 'PFM - Approval PBI APBD: Operator Dinsos',
        'pbi-kabid' => 'PFM - Approval PBI APBD: Kepala Bidang',
        'pbi-kadis' => 'PFM - Approval PBI APBD: Kepala Dinas',
        'pbi-dinkes' => 'PFM - Approval PBI APBD: Dinas Kesehatan',
        'pbi-bpjs' => 'PFM - Approval PBI APBD: BPJS Kesehatan',

        // --- Dayasos ---
        'dayasos-ngopi-pagi' => 'Dayasos - Ngopi Pagi',
        'dayasos-kesan' => 'Dayasos - Kesan',

        // --- Perlinsos ---
        'sigap-bencana' => 'Perlinsos - SIGAP Bencana (Dinsos)',
        'sigap-proses' => 'Perlinsos - Proses Bantuan (Kelurahan/OPD Wilayah)',

        // --- Rehabsos ---
        'rehabsos-ppks' => 'Rehabsos - PPKS',
        'rehabsos-rumah-singgah' => 'Rehabsos - Rumah Singgah',
        'rehabsos-bantuan' => 'Rehabsos - Data Permohonan Bantuan',
        'rehabsos-ground-check' => 'Rehabsos - Ground Check 2026',

        // --- Ground Check ---
        'ground-check' => 'Ground Check - Entry Data Ground Check 2026',

        // --- Kelurahan ---
        'pbi-kelurahan' => 'Verifikasi Kelurahan - PBI APBD',
        'layanan-kartu-kks' => 'Layanan Kelurahan - Pengajuan Kartu KKS',
        'layanan-dtsen' => 'Layanan Kelurahan - Pengajuan DTSEN',

        // --- Lainnya ---
        'asesmen-spmb' => 'Asesmen SPMB',
        'kedaruratan-medis' => 'Kedaruratan Medis (belum ada di menu)',
        'dokumen' => 'Dokumen - Lihat & Unduh Template',
    ];

    /**
     * Pakai `slug` sebagai slug di URL (route model binding), bukan `id`.
     */
    public function getRouteKeyName(): string
    {
        return 'slug';
    }

    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }

    /**
     * Slug yang sudah dinormalisasi (lowercase, strip -/spasi jadi _).
     */
    public function normalizedSlug(): string
    {
        return strtolower(str_replace(['-', ' '], '_', $this->slug ?? ''));
    }

    /**
     * Super Admin SELALU bypass semua pengecekan modul.
     */
    public function isSuperAdmin(): bool
    {
        return in_array($this->normalizedSlug(), ['superadmin', 'super_admin'], true);
    }

    /**
     * Cek apakah role ini boleh mengakses modul tertentu (key di MODULES).
     */
    public function hasModule(string $key): bool
    {
        if ($this->isSuperAdmin()) {
            return true;
        }

        return in_array($key, $this->permissions ?? [], true);
    }
}
