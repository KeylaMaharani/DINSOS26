@extends('layouts.admin')

@section('title', 'Detail Ajuan PBI APBD')
@section('page_title', 'PBI APBD — Detail Ajuan')

@section('head')
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
@endsection

@php
    $statusColor = match($data->status) {
        'disetujui' => 'bg-success-container text-on-success-container',
        'ditolak' => 'bg-error-container text-on-error-container',
        default => 'bg-secondary-fixed text-on-secondary-container',
    };
@endphp

@section('content')
<div class="space-y-5 max-w-5xl">

    <a href="{{ route('pbi-apbd.ajuan.index') }}" class="inline-flex items-center gap-1 text-sm text-on-surface-variant hover:text-primary transition-colors">
        <span class="material-symbols-outlined text-[18px]">arrow_back</span> Kembali ke daftar Ajuan
    </a>

    @if (session('success'))
        <div class="px-4 py-3 rounded-lg bg-success-container text-on-success-container text-sm shadow-sm">
            {{ session('success') }}
        </div>
    @endif
    @if (session('error'))
        <div class="px-4 py-3 rounded-lg bg-error-container text-on-error-container text-sm shadow-sm">
            {{ session('error') }}
        </div>
    @endif

    {{-- Header ringkas --}}
    <div class="bg-surface-container-lowest border border-outline-variant/40 rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-sm">
        <div>
            <p class="text-xs text-on-surface-variant uppercase tracking-wider font-medium">No. Registrasi</p>
            <h2 class="text-xl font-bold text-primary mt-0.5">{{ $data->no_registrasi }}</h2>
            <p class="text-sm text-on-surface-variant mt-1">{{ $data->nama_kepala_keluarga }} &mdash; NIK {{ $data->nik_kepala_keluarga }}</p>
        </div>
        <span class="inline-flex items-center px-4 py-1.5 rounded-full text-sm font-semibold {{ $statusColor }}">
            {{ $data->statusLabel() }}
        </span>
    </div>

    {{-- 1. Data Permohonan --}}
    <div class="bg-surface-container-lowest border border-outline-variant/40 rounded-xl overflow-hidden shadow-sm">
        <div class="px-5 py-4 border-b border-outline-variant/40 bg-surface-container-lowest">
            <h3 class="text-sm font-bold flex items-center gap-2">
                <span class="material-symbols-outlined text-[20px] text-secondary">assignment</span>
                Data Permohonan
            </h3>
        </div>
        <dl class="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4 p-5 text-sm">
            @foreach ([
                'Nama Layanan' => $data->nama_layanan,
                'No KK' => $data->no_kk,
                'Nama Kepala Keluarga' => $data->nama_kepala_keluarga,
                'NIK Kepala Keluarga' => $data->nik_kepala_keluarga,
                'Alamat' => $data->alamat,
                'RT/RW' => $data->rt . ' / ' . $data->rw,
                'Provinsi' => $data->provinsi,
                'Kab/Kota' => $data->kabupaten_kota,
                'Kecamatan' => $data->kecamatan,
                'Desa/Kelurahan' => $data->desa_kelurahan,
                'No Telp' => $data->no_telp,
                'Email' => $data->email,
            ] as $label => $value)
                <div>
                    <dt class="text-xs text-on-surface-variant mb-0.5">{{ $label }}</dt>
                    <dd class="font-semibold text-on-surface">{{ $value ?: '-' }}</dd>
                </div>
            @endforeach
        </dl>
    </div>

    {{-- Anggota Keluarga --}}
    <div class="bg-surface-container-lowest border border-outline-variant/40 rounded-xl overflow-hidden shadow-sm">
        <div class="px-5 py-4 border-b border-outline-variant/40">
            <h3 class="text-sm font-bold flex items-center gap-2">
                <span class="material-symbols-outlined text-[20px] text-secondary">group</span>
                Anggota Keluarga Yang Didaftarkan
            </h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left">
                <thead class="bg-surface-container/50 text-on-surface-variant text-xs uppercase tracking-wider">
                    <tr>
                        <th class="px-5 py-3 font-medium">NIK</th>
                        <th class="px-5 py-3 font-medium">Nama</th>
                        <th class="px-5 py-3 font-medium">Tempat/Tgl Lahir</th>
                        <th class="px-5 py-3 font-medium">Pekerjaan</th>
                        <th class="px-5 py-3 font-medium">Agama</th>
                        <th class="px-5 py-3 font-medium">JK</th>
                        <th class="px-5 py-3 font-medium">Hub. Keluarga</th>
                        <th class="px-5 py-3 font-medium">BPJS</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-outline-variant/30">
                    @forelse ($data->daftarPeserta() as $anggota)
                        <tr class="hover:bg-surface-container-lowest/50 transition-colors">
                            <td class="px-5 py-3">{{ $anggota->nik }}</td>
                            <td class="px-5 py-3 font-medium text-on-surface">{{ $anggota->nama }}</td>
                            <td class="px-5 py-3">{{ $anggota->tempat_lahir }}, {{ optional($anggota->tanggal_lahir)->format('d-m-Y') }}</td>
                            <td class="px-5 py-3">{{ $anggota->pekerjaan }}</td>
                            <td class="px-5 py-3">{{ $anggota->agama }}</td>
                            <td class="px-5 py-3">{{ $anggota->jenis_kelamin }}</td>
                            <td class="px-5 py-3">{{ $anggota->hubungan_keluarga }}</td>
                            <td class="px-5 py-3">{{ $anggota->keanggotaan_bpjs }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="8" class="px-5 py-6 text-center text-on-surface-variant">Belum ada data anggota keluarga.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- 2. Koordinat & Peta --}}
    <div class="bg-surface-container-lowest border border-outline-variant/40 rounded-xl overflow-hidden shadow-sm">
        <div class="px-5 py-4 border-b border-outline-variant/40">
            <h3 class="text-sm font-bold flex items-center gap-2">
                <span class="material-symbols-outlined text-[20px] text-secondary">location_on</span>
                Koordinat & Data Desil
            </h3>
        </div>
        @if ($data->latitude && $data->longitude)
            <div id="peta-detail" class="w-full h-[300px] bg-surface-container"></div>
        @else
            <div class="w-full h-32 flex items-center justify-center bg-surface-container/30">
                <p class="text-sm text-on-surface-variant">Koordinat lokasi belum tersedia.</p>
            </div>
        @endif
        <dl class="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4 p-5 text-sm">
            <div class="sm:col-span-2">
                <dt class="text-xs text-on-surface-variant mb-0.5">Desil Nasional</dt>
                <dd class="font-semibold text-on-surface">{{ $data->desil_nasional ?: '-' }}</dd>
            </div>
            <div class="sm:col-span-2">
                <dt class="text-xs text-on-surface-variant mb-0.5">Catatan Kelengkapan/Kekurangan Berkas</dt>
                <dd class="font-semibold text-on-surface">{{ $data->catatan_berkas ?: '-' }}</dd>
            </div>
        </dl>
    </div>

    {{-- Lampiran --}}
    <div class="bg-surface-container-lowest border border-outline-variant/40 rounded-xl overflow-hidden shadow-sm">
        <div class="px-5 py-4 border-b border-outline-variant/40">
            <h3 class="text-sm font-bold flex items-center gap-2">
                <span class="material-symbols-outlined text-[20px] text-secondary">attach_file</span>
                Lampiran Persyaratan
            </h3>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 p-5">
            @foreach ([
                'scan_ktp' => 'Scan KTP',
                'scan_kk' => 'Scan Kartu Keluarga',
                'foto_rumah' => 'Foto Rumah Pemohon',
                'foto_kamar_mandi' => 'Foto Kamar Mandi',
                'foto_selfie_ktp' => 'Foto Selfie dengan KTP',
                'surat_rawat_inap' => 'Surat Ket. Rawat Inap',
                'screenshot_pembaharuan_desil' => 'Screenshot Pembaharuan Desil',
                'screenshot_dtsen' => 'Screenshot DTSEN',
            ] as $field => $label)
                <x-lampiran-preview
                    :src="$data->$field ? asset('storage/' . $data->$field) : null"
                    :label="$label" />
            @endforeach
        </div>
    </div>

    <!--{{-- Diagnosa: hanya lihat (edit hanya di Dinkes) --}}-->
    <!--@include('admin.pbi-apbd.partials.diagnosa-edit', ['canDiagnosa' => false])-->
    
    {{-- Diagnosa (riwayat, baca saja) --}}
    <div class="bg-surface-container-lowest border border-outline-variant/40 rounded-xl overflow-hidden shadow-sm">
        <div class="px-5 py-4 border-b border-outline-variant/40">
            <h3 class="text-sm font-bold flex items-center gap-2"><span class="material-symbols-outlined text-[20px] text-secondary">medical_information</span> Diagnosa</h3>
        </div>
        <div class="p-5 space-y-2 max-h-64 overflow-y-auto">
            @forelse ($data->diagnosaLogs as $log)
                <div class="p-3 bg-surface-container/30 rounded-lg border border-outline-variant/30">
                    <div class="flex justify-between gap-2 flex-wrap mb-1">
                        <span class="text-xs font-semibold">{{ $log->username }} <span class="font-normal text-on-surface-variant">({{ $log->role_name }})</span></span>
                        <span class="text-[11px] text-on-surface-variant">{{ $log->created_at->format('d M Y - H:i') }}</span>
                    </div>
                    <p class="text-sm">{{ $log->diagnosa }}</p>
                </div>
            @empty
                <p class="text-sm text-on-surface-variant italic">Belum ada diagnosa yang tercatat.</p>
            @endforelse
        </div>
    </div>

    @include('admin.pbi-apbd.partials.hasil-verifikasi')

    {{-- 6. Fasilitas Kesehatan (editable) --}}
    <div class="bg-surface-container-lowest border border-outline-variant/40 rounded-xl overflow-hidden shadow-sm">
        <div class="px-5 py-4 border-b border-outline-variant/40">
            <h3 class="text-sm font-bold flex items-center gap-2">
                <span class="material-symbols-outlined text-[20px] text-secondary">local_hospital</span>
                Fasilitas Kesehatan
            </h3>
        </div>
        @if ($canAct)
            <form method="POST" action="{{ route('pbi-apbd.ajuan.updateTambahan', $data) }}" class="p-5 grid grid-cols-1 md:grid-cols-3 gap-6">
                @csrf
                @method('PUT')
                <div class="md:col-span-1">
                     <label class="block text-sm font-bold text-on-surface mb-1">Pilih Faskes</label>
                     <p class="text-xs text-on-surface-variant">Tentukan faskes terdekat pemohon.</p>
                </div>
                <div class="md:col-span-2">
                    <select name="nama_faskes"
                        class="w-full px-4 py-3 rounded-lg border border-outline-variant/60 text-sm focus:outline-none focus:ring-2 focus:ring-[#003B5C]/40 focus:border-[#003B5C] bg-white shadow-sm transition-shadow">
                        <option value="">- Pilih Faskes Terdekat -</option>
                        @foreach ($faskesOptions as $opt)
                            <option value="{{ $opt }}" @selected(old('nama_faskes', $data->nama_faskes) === $opt)>{{ $opt }}</option>
                        @endforeach
                        @if ($data->nama_faskes && !in_array($data->nama_faskes, $faskesOptions))
                            <option value="{{ $data->nama_faskes }}" selected>{{ $data->nama_faskes }} (tersimpan)</option>
                        @endif
                    </select>
                    @error('nama_faskes')
                        <p class="text-xs text-error mt-1">{{ $message }}</p>
                    @enderror
                    @if (empty($faskesOptions))
                        <p class="text-xs text-warning mt-2 bg-warning-container/20 p-2 rounded border border-warning/20">Belum ada data faskes untuk kecamatan "{{ $data->kecamatan ?: '-' }}". Data master faskes masih sementara — lengkapi di config/faskes.php.</p>
                    @endif
                    <div class="mt-4">
                        <button type="submit"
                            class="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#003B5C] text-white hover:bg-[#002A42] text-sm font-medium transition-all shadow-sm">
                            <span class="material-symbols-outlined text-[18px]">save</span>
                            Simpan Faskes
                        </button>
                    </div>
                </div>
            </form>
        @else
            <dl class="p-5 text-sm grid grid-cols-1 md:grid-cols-3 gap-6">
                <dt class="md:col-span-1 text-sm font-bold text-on-surface">Nama Faskes</dt>
                <dd class="md:col-span-2 font-semibold text-on-surface bg-surface-container/30 px-4 py-2.5 rounded-lg border border-outline-variant/30">{{ $data->nama_faskes ?: 'Belum ditentukan' }}</dd>
            </dl>
        @endif
    </div>

    {{-- Log Proses --}}
    <div class="bg-surface-container-lowest border border-outline-variant/40 rounded-xl overflow-hidden shadow-sm">
        <div class="px-5 py-4 border-b border-outline-variant/40">
            <h3 class="text-sm font-bold flex items-center gap-2">
                <span class="material-symbols-outlined text-[20px] text-secondary">history</span>
                Log Proses
            </h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left">
                <thead class="bg-surface-container/50 text-on-surface-variant text-xs uppercase tracking-wider">
                    <tr>
                        <th class="px-5 py-3 font-medium">Tanggal Proses</th>
                        <th class="px-5 py-3 font-medium">Username</th>
                        <th class="px-5 py-3 font-medium">Role</th>
                        <th class="px-5 py-3 font-medium">Aktivitas</th>
                        <th class="px-5 py-3 font-medium">Catatan</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-outline-variant/30">
                    @forelse ($data->logs as $log)
                        <tr class="hover:bg-surface-container-lowest/50 transition-colors">
                            <td class="px-5 py-3 whitespace-nowrap text-on-surface-variant">{{ $log->created_at->format('d M Y - H:i') }}</td>
                            <td class="px-5 py-3 font-medium text-on-surface">{{ $log->username }}</td>
                            <td class="px-5 py-3"><span class="bg-surface-container px-2 py-1 rounded text-xs">{{ $log->role_name }}</span></td>
                            <td class="px-5 py-3 font-medium">{{ $log->task_name }}</td>
                            <td class="px-5 py-3 text-on-surface-variant">{{ $log->catatan ?: '-' }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="5" class="px-5 py-6 text-center text-on-surface-variant">Belum ada log proses.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- Aksi alur (Simpan / Next / Back / Reject) --}}
    <div class="bg-surface-container-lowest border border-outline-variant/40 rounded-xl overflow-hidden shadow-sm mb-10">
        <div class="px-5 py-4 border-b border-outline-variant/40 bg-surface-container/20">
            <h3 class="text-sm font-bold flex items-center gap-2">
                <span class="material-symbols-outlined text-[20px] text-secondary">alt_route</span>
                Proses Permohonan
            </h3>
        </div>

        @if ($data->isFinal())
            <div class="p-6 text-center bg-surface-container-lowest">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-full {{ $data->status === 'disetujui' ? 'bg-success/20 text-success' : 'bg-error/20 text-error' }} mb-3">
                    <span class="material-symbols-outlined text-[24px]">{{ $data->status === 'disetujui' ? 'check_circle' : 'cancel' }}</span>
                </div>
                <h4 class="text-lg font-bold mb-1">Permohonan Final</h4>
                <p class="text-sm text-on-surface-variant">
                    Permohonan ini telah final dengan status <strong>{{ $data->statusLabel() }}</strong>. Tidak ada aksi lanjutan.
                </p>
            </div>
        @elseif (!$canAct)
            <div class="p-6 text-center bg-surface-container-lowest">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-full bg-warning/20 text-warning mb-3">
                    <span class="material-symbols-outlined text-[24px]">hourglass_empty</span>
                </div>
                <h4 class="text-lg font-bold mb-1">Menunggu Tahap Selanjutnya</h4>
                <p class="text-sm text-on-surface-variant">
                    Permohonan ini sedang berada di tahap <strong>{{ $data->currentStageLabel() }}</strong>.<br>
                    Anda tidak berwenang memproses pada tahap ini.
                </p>
            </div>
        @else
            <form method="POST" action="{{ route('pbi-apbd.ajuan.aksi', $data) }}" class="p-5" x-data="{ aksi: null }">
                @csrf
                <div class="mb-5">
                    <label class="block text-sm font-bold text-on-surface mb-2">Catatan Proses <span class="text-error">*</span></label>
                    <textarea name="catatan" rows="3" required placeholder="Tulis catatan (wajib diisi, terutama jika ingin Reject)..."
                        class="w-full px-4 py-3 rounded-lg border border-outline-variant/60 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary shadow-sm"></textarea>
                </div>
                <div class="flex flex-col sm:flex-row flex-wrap items-center gap-3">
                    @if ($data->previousStageKey())
                        <button type="submit" name="aksi" value="back"
                            class="w-full sm:w-auto inline-flex justify-center items-center gap-2 px-5 py-2.5 rounded-lg border border-outline-variant hover:bg-surface-container-highest text-on-surface text-sm font-bold transition-all">
                            <span class="material-symbols-outlined text-[18px]">undo</span>
                            Kembalikan ke {{ \App\Models\PbiApbd::STAGES[$data->previousStageKey()]['label'] }}
                        </button>
                    @endif

                    <button type="submit" name="aksi" value="simpan"
                        class="w-full sm:w-auto inline-flex justify-center items-center gap-2 px-5 py-2.5 rounded-lg bg-surface-container hover:bg-secondary/20 text-secondary text-sm font-bold transition-all">
                        <span class="material-symbols-outlined text-[18px]">save</span>
                        Simpan Catatan Saja
                    </button>

                    <button type="submit" name="aksi" value="next"
                        class="w-full sm:w-auto inline-flex justify-center items-center gap-2 px-6 py-2.5 rounded-lg bg-primary text-on-primary hover:bg-secondary text-sm font-bold shadow-md transition-all sm:ml-auto">
                        <span class="material-symbols-outlined text-[18px]">{{ $data->nextStageKey() === 'disetujui' ? 'check_circle' : 'redo' }}</span>
                        @if ($data->nextStageKey() === 'disetujui')
                            Setujui Final
                        @else
                            Teruskan ke {{ \App\Models\PbiApbd::STAGES[$data->nextStageKey()]['label'] }}
                        @endif
                    </button>

                    <button type="submit" name="aksi" value="reject"
                        onclick="return confirm('Yakin ingin menolak permohonan ini?');"
                        class="w-full sm:w-auto inline-flex justify-center items-center gap-2 px-5 py-2.5 rounded-lg border border-error text-error hover:bg-error hover:text-on-error text-sm font-bold transition-all">
                        <span class="material-symbols-outlined text-[18px]">cancel</span>
                        Tolak (Reject)
                    </button>
                </div>
            </form>
        @endif
    </div>

</div>
@endsection

@push('scripts')
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
@if ($data->latitude && $data->longitude)
<script>
    const lat = {{ $data->latitude }};
    const lng = {{ $data->longitude }};
    const map = L.map('peta-detail').setView([lat, lng], 16);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    L.marker([lat, lng]).addTo(map).bindPopup(@json($data->alamat)).openPopup();
</script>
@endif
@endpush