<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>@yield('title', 'SOLID v4 Dinas Sosial Kota Bogor')</title>
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link rel="icon" type="image/png" href="{{ asset('assets/img/logo/logo.png') }}" />
    <link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect" />
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&amp;display=swap"
        rel="stylesheet" />
    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"
        rel="stylesheet" />
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js"></script>
    <script>
        (function() {
            const originalWarn = console.warn;
            console.warn = function(...args) {
                if (args[0] && String(args[0]).includes('cdn.tailwindcss.com')) return;
                originalWarn.apply(console, args);
            };
        })();
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "outline-variant": "#c2c7cf",
                        surface: "#f7f9ff",
                        "primary-fixed-dim": "#a0caf9",
                        "surface-variant": "#d9e3f1",
                        "on-primary": "#ffffff",
                        "surface-container-highest": "#d9e3f1",
                        "surface-container-high": "#dfe9f7",
                        "surface-container": "#e4effd",
                        "on-secondary": "#ffffff",
                        "primary-container": "#24527a",
                        error: "#ba1a1a",
                        "error-container": "#ffdad6",
                        "on-error-container": "#93000a",
                        "on-error": "#ffffff",
                        "surface-dim": "#d1dbe8",
                        "surface-container-low": "#edf4ff",
                        "surface-container-lowest": "#ffffff",
                        "secondary-fixed": "#cfe5ff",
                        "secondary-container": "#82c1fd",
                        primary: "#003b62",
                        brand: "#0a5ca8",
                        "brand-soft": "#e8f4fd",
                        "on-surface": "#121d26",
                        outline: "#72777f",
                        "on-surface-variant": "#42474e",
                        secondary: "#136299",
                        "secondary-fixed-dim": "#98cbff",
                        "on-secondary-container": "#004e7e",
                        "surface-bright": "#f7f9ff",
                        "on-background": "#121d26",
                        background: "#f7f9ff",
                        "success-container": "#d0f8d0",
                        "on-success-container": "#0a5e0a",
                        success: "#2e7d32",
                        "warning-container": "#fff3cd",
                        "on-warning-container": "#7a5b00",
                        warning: "#b98900",
                    },
                    borderRadius: {
                        DEFAULT: "0.25rem",
                        lg: "0.5rem",
                        xl: "0.75rem",
                        full: "9999px",
                    },
                    fontFamily: {
                        "body-lg": ["Plus Jakarta Sans"],
                        "body-sm": ["Plus Jakarta Sans"],
                        "headline-lg-mobile": ["Plus Jakarta Sans"],
                        "label-sm": ["Plus Jakarta Sans"],
                        "headline-sm": ["Plus Jakarta Sans"],
                        "label-md": ["Plus Jakarta Sans"],
                        "label-lg": ["Plus Jakarta Sans"],
                        "headline-md": ["Plus Jakarta Sans"],
                        "body-md": ["Plus Jakarta Sans"],
                        "headline-lg": ["Plus Jakarta Sans"],
                    },
                },
            },
        };
    </script>
    @yield('head')
    @stack('styles')
    <style>
        /* Sembunyikan elemen yang belum sempat diinisialisasi Alpine.js,
           supaya tidak "kedip" muncul sebelum disembunyikan (misal overlay sidebar). */
        [x-cloak] {
            display: none !important;
        }

        /* Sembunyikan scrollbar tapi tetap bisa discroll */
        * {
            scrollbar-width: none;
            -ms-overflow-style: none;
        }

        *::-webkit-scrollbar {
            display: none;
            width: 0;
            height: 0;
        }

        /* Scrollbar tipis yang tetap terlihat (khusus sidebar & panel melayang).
           Diletakkan SETELAH aturan global di atas agar menimpanya. */
        .sidebar-scroll {
            scrollbar-width: thin;
            /* Firefox */
            scrollbar-color: rgba(255, 255, 255, 0.45) transparent;
            /* thumb | track */
            -ms-overflow-style: auto;
        }

        .sidebar-scroll::-webkit-scrollbar {
            display: block;
            width: 6px;
            height: 6px;
        }

        .sidebar-scroll::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.12);
            border-radius: 9999px;
            margin: 6px 0;
        }

        .sidebar-scroll::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.55);
            border-radius: 9999px;
        }

        .sidebar-scroll::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.8);
        }

        /* Versi untuk panel melayang (latar putih) saat sidebar diciutkan */
        .sidebar-scroll-light {
            scrollbar-width: thin;
            scrollbar-color: #c2c7cf transparent;
            -ms-overflow-style: auto;
        }

        .sidebar-scroll-light::-webkit-scrollbar {
            display: block;
            width: 6px;
            height: 6px;
        }

        .sidebar-scroll-light::-webkit-scrollbar-track {
            background: #edf4ff;
            border-radius: 9999px;
            margin: 6px 0;
        }

        .sidebar-scroll-light::-webkit-scrollbar-thumb {
            background: #c2c7cf;
            border-radius: 9999px;
        }

        /* ====== Flipbook (buku panduan bantuan) ====== */
        #help-flipbook .page {
            background-color: #ffffff;
            overflow: hidden;
            box-shadow: inset 0 0 15px rgba(0, 0, 0, 0.03);
            /* Tambahan shadow tipis di dalam buku */
            border-right: 1px solid rgba(0, 0, 0, 0.05);
            /* Batas lipatan tengah */
        }

        /* page-flip me-render tiap halaman sebagai <img> ketika dimuat lewat
           loadFromImages()/updateFromImages() -- jaga rasio asli, tidak digepengkan */
        #help-flipbook img {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        /* Buku terasa lebih natural: sudut sedikit membulat & rasio halaman dijaga */
        #help-flipbook {
            border-radius: 6px;
        }

        .stf__parent {
            margin: 0 auto;
        }

        #help-flipbook-search-highlight {
            transition: opacity 0.3s ease;
        }
    </style>
</head>

<body class="bg-brand-soft font-body-md text-on-surface antialiased">
    @php
        // Role user yang sedang login, dipakai untuk menyaring menu sidebar
        // sesuai kolom `permissions`-nya. Super Admin (isSuperAdmin()) selalu
        // lolos semua pengecekan hasModule() di bawah.
        $currentRole = auth()->user()->role ?? null;

        // URL file PDF panduan penggunaan yang akan ditampilkan sebagai flipbook.
        // Taruh file PDF-nya di public/assets/help/panduan-penggunaan.pdf,
        // atau ganti path di bawah ini sesuai lokasi file kamu.
        $helpPdfUrl = asset('assets/help/panduan-penggunaan.pdf');

        /* ====================================================================
         |  PETA MENU SIDEBAR (bertingkat, per bidang)
         |
         |  Satu node bisa berisi:
         |    label            teks menu
         |    icon             ikon (hanya untuk menu paling atas)
         |    route            nama route -> node ini menjadi LINK
         |    match            pola route tambahan agar menu tetap "aktif" (opsional)
         |    children         anak menu -> node ini menjadi FOLDER
         |    module           key di Role::MODULES (string / array = salah satu).
         |                     Anak menu otomatis mengikuti modul induknya.
         |    superadmin_only  hanya Super Admin
         |    hide_for_superadmin  disembunyikan untuk Super Admin
         |    separator        node PEMISAH grup (hanya berisi teks label, mis.
         |                     ['separator' => 'Data Master']). Tampil hanya jika
         |                     ada menu di bawahnya yang boleh dilihat role.
         |  Menu yang route-nya belum terdaftar otomatis disembunyikan.
         * ==================================================================== */

        // --- Rehabsos: anak menu dibaca dari config/rehabsos.php ---
        $rehabChildren = [
            [
                'label' => 'Beranda',
                'route' => 'rehabsos.dashboard',
                'module' => ['rehabsos-ppks', 'rehabsos-rumah-singgah', 'rehabsos-bantuan'],
            ],
        ];
        foreach (config('rehabsos.groups', []) as $gk => $g) {
            $rehabChildren[] = [
                'label' => $g['label'],
                'module' => $g['module'],
                'children' => collect($g['items'])
                    ->map(fn($label, $ik) => ['label' => $label, 'route' => "rehabsos.{$gk}.{$ik}"])
                    ->values()
                    ->all(),
            ];
        }

        $sidebar = [
            [
                'label' => 'Beranda',
                'icon' => 'dashboard',
                'route' => 'dashboard',
                'module' => 'beranda',
            ],

            // ==================== FRONT END ====================
            ['separator' => 'Front End'],

            // ---------- Menu Frontend (dibaca dari config/frontend.php) ----------
            ...config('frontend', []),

            // ==================== MODUL ====================
            ['separator' => 'Modul'],

            // ---------- Modul Asesmen SPMB (tepat di bawah separator Modul) ----------
            [
                'label' => 'Modul Asesmen SPMB',
                'icon' => 'fact_check',
                'route' => 'asesmen_spmb.ajuan',
                'match' => ['asesmen_spmb.*'],
                'module' => 'asesmen-spmb',
            ],

            // ---------- PFM ----------
            [
                'label' => 'Modul P. Fakir Miskin',
                'icon' => 'account_balance_wallet',
                'children' => [
                    ['label' => 'Beranda', 'route' => 'pfm.beranda', 'module' => ['pbi-apbd', 'kartu-kks', 'dtsen']],
                    [
                        'label' => 'PBI APBD',
                        'module' => 'pbi-apbd',
                        'children' => [
                            ['label' => 'Ajuan', 'route' => 'pbi-apbd.ajuan.index', 'match' => ['pbi-apbd.ajuan.*']],
                            ['label' => 'Arsip', 'route' => 'pbi-apbd.arsip.index', 'match' => ['pbi-apbd.arsip.*']],
                            ['label' => 'Monitoring', 'route' => 'pbi-apbd.monitoring.index'],
                        ],
                    ],
                    [
                        'label' => 'Kartu KKS',
                        'module' => 'kartu-kks',
                        'children' => [
                            ['label' => 'Ajuan', 'route' => 'kartu-kks.ajuan', 'match' => ['kartu-kks.show', 'kartu-kks.detail*', 'kartu-kks.proses']],
                            ['label' => 'Arsip', 'route' => 'kartu-kks.arsip'],
                            ['label' => 'Monitoring', 'route' => 'kartu-kks.monitoring'],
                        ],
                    ],
                    [
                        'label' => 'DTSEN',
                        'module' => 'dtsen',
                        'children' => [
                            ['label' => 'Ajuan', 'route' => 'dtsen.ajuan', 'match' => ['dtsen.show', 'dtsen.detail*', 'dtsen.bansos.*', 'dtsen.lampiran.*', 'dtsen.proses']],
                            ['label' => 'Arsip', 'route' => 'dtsen.arsip'],
                            ['label' => 'Monitoring', 'route' => 'dtsen.monitoring'],
                        ],
                    ],
                ],
            ],

            // ---------- Dayasos (kerangka menu, dibaca dari config/dayasos.php) ----------
            [
                'label' => 'Modul Dayasos',
                'icon' => 'groups',
                'children' => config('dayasos', []),
            ],

            // ---------- Perlinsos ----------
            [
                'label' => 'Modul Perlinsos',
                'icon' => 'crisis_alert',
                'children' => [
                    ['label' => 'Beranda', 'route' => 'perlinsos.dashboard', 'module' => 'sigap-bencana'],
                    [
                        'label' => 'Sigap Bencana',
                        'module' => 'sigap-bencana',
                        'children' => [
                            ['label' => 'Laporan Bantuan Bencana', 'route' => 'sigap.index', 'match' => ['sigap.show', 'sigap.create']],
                            ['label' => 'Stock Barang', 'route' => 'sigap.stok.index', 'match' => ['sigap.stok.*']],
                            ['label' => 'Laporan', 'route' => 'perlinsos.laporan'],
                        ],
                    ],
                ],
            ],

            // ---------- Rehabsos ----------
            [
                'label' => 'Modul Rehabsos',
                'icon' => 'diversity_1',
                'children' => $rehabChildren,
            ],

            // ---------- Ground Check (alur entry data SOLID) ----------
            [
                'label' => 'Modul Ground Check',
                'icon' => 'task_alt',
                'module' => 'ground-check',
                'children' => [
                    ['label' => 'Ground Check 2026', 'route' => 'ground-check.index', 'match' => ['ground-check.*']],
                ],
            ],

            // ---------- Menu tunggal ----------
            [
                'label' => 'Verifikasi Kelurahan',
                'icon' => 'home_work',
                'route' => 'pbi-kelurahan.index',
                'match' => ['pbi-kelurahan.*'],
                'module' => 'pbi-kelurahan',
            ],
            // Kelurahan / OPD wilayah: HANYA satu menu ini untuk SIGAP
            [
                'label' => 'Proses Bantuan Kebencanaan',
                'icon' => 'volunteer_activism',
                'route' => 'sigap.proses.index',
                'match' => ['sigap.proses.*', 'sigap.show'],
                'module' => 'sigap-proses',
                'hide_for_superadmin' => true,
            ],

            // ==================== DATA MASTER ====================
            ['separator' => 'Data Master'],

            // Kelola Akses & Master Kriteria SENGAJA tidak ada di Role::MODULES (khusus Super Admin)
            [
                'label' => 'Kelola Akses',
                'icon' => 'manage_accounts',
                'route' => 'akun.index',
                'match' => ['akun.*'],
                'superadmin_only' => true,
            ],
            [
                'label' => 'Master Kriteria',
                'icon' => 'rule',
                'superadmin_only' => true,
                'children' => [
                    ['label' => 'Kriteria PBI', 'route' => 'master.kriteria.index', 'match' => ['master.kriteria.*']],
                    ['label' => 'Kriteria Ground Check', 'route' => 'master.gc-kriteria.index', 'match' => ['master.gc-kriteria.*']],
                ],
            ],
        ];

        // ---------- Fungsi bantu render menu ----------
        $hasMod = fn($m) => $currentRole && collect((array) $m)->contains(fn($k) => $currentRole->hasModule($k));

        // Node tampil jika: lolos aturan akses, dan (link -> route-nya ada) / (folder -> ada anak yang tampil)
        $visible = function (array $n) use (&$visible, $currentRole, $hasMod) {
            if (!$currentRole) {
                return false;
            }
            if (!empty($n['superadmin_only']) && !$currentRole->isSuperAdmin()) {
                return false;
            }
            if (!empty($n['hide_for_superadmin']) && $currentRole->isSuperAdmin()) {
                return false;
            }
            if (isset($n['module']) && !$hasMod($n['module'])) {
                return false;
            }
            if (isset($n['children'])) {
                return collect($n['children'])->contains(fn($c) => $visible($c));
            }

            return isset($n['route']) && \Illuminate\Support\Facades\Route::has($n['route']);
        };

        // Node aktif jika halaman sekarang ada di dalamnya (folder: salah satu turunannya)
        $active = function (array $n) use (&$active) {
            if (isset($n['children'])) {
                return collect($n['children'])->contains(fn($c) => $active($c));
            }

            return request()->routeIs(...array_merge([$n['route']], $n['match'] ?? []));
        };

        // Susun daftar menu yang benar-benar ditampilkan di sidebar.
        // Separator hanya ikut jika ada menu yang lolos $visible sesudahnya
        // (sebelum separator berikutnya), jadi tidak ada label "kosong".
        $menuItems = [];
        $pendingSeparator = null;
        foreach ($sidebar as $node) {
            if (isset($node['separator'])) {
                $pendingSeparator = $node;
                continue;
            }
            if (!$visible($node)) {
                continue;
            }
            if ($pendingSeparator) {
                $menuItems[] = $pendingSeparator;
                $pendingSeparator = null;
            }
            $menuItems[] = $node;
        }

        // Render anak menu (rekursif, kedalaman berapa pun). $floating = versi panel melayang (sidebar ciut)
        $renderChildren = function (array $nodes, bool $floating) use (&$renderChildren, $visible, $active) {
            $on = $floating ? 'bg-brand/10 text-brand font-semibold' : 'bg-white/20 text-white font-semibold';
            $off = $floating
                ? 'text-on-surface-variant hover:bg-surface-container'
                : 'text-white/70 hover:bg-white/10 hover:text-white';
            $head = $floating ? 'text-on-surface hover:bg-surface-container' : 'text-white/90 hover:bg-white/10';
            $line = $floating ? 'border-outline-variant/40' : 'border-white/20';

            $html = '';
            foreach ($nodes as $n) {
                if (!$visible($n)) {
                    continue;
                }

                if (isset($n['children'])) {
                    $open = $active($n) ? 'true' : 'false';
                    $html .=
                        '<div x-data="{ g: ' . $open . ' }">' .
                        '<button type="button" x-on:click="g = !g" class="w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-[13px] font-semibold transition-colors ' . $head . '">' .
                        '<span class="text-left">' . e($n['label']) . '</span>' .
                        '<span class="material-symbols-outlined text-[16px] transition-transform" :class="g ? \'rotate-180\' : \'\'">expand_more</span>' .
                        '</button>' .
                        '<div x-show="g" x-cloak class="ml-3 pl-3 border-l ' . $line . ' space-y-0.5">' .
                        $renderChildren($n['children'], $floating) .
                        '</div></div>';
                } else {
                    $html .=
                        '<a href="' . route($n['route']) . '" class="block px-3 py-1.5 rounded-lg text-[13px] transition-colors ' .
                        ($active($n) ? $on : $off) . '">' . e($n['label']) . '</a>';
                }
            }

            return $html;
        };
    @endphp

    {{-- Status sidebar:
         - collapsedPref : pilihan pengguna (disimpan di localStorage), true = hanya ikon
         - desktop       : true di layar >= lg. Di layar kecil sidebar selalu tampil penuh (ikon + nama)
         - collapsed     : hasil gabungan keduanya, dipakai oleh seluruh isi sidebar --}}
    <div class="flex h-screen overflow-hidden" x-data="{
        sidebarOpen: false,
        collapsedPref: (function() { try { return localStorage.getItem('sidebarCollapsed') === '1'; } catch (e) { return false; } })(),
        desktop: window.innerWidth >= 1024,
        get collapsed() { return this.collapsedPref && this.desktop; },
        toggleSidebar() {
            this.collapsedPref = !this.collapsedPref;
            try { localStorage.setItem('sidebarCollapsed', this.collapsedPref ? '1' : '0'); } catch (e) {}
        }
    }"
        @resize.window="desktop = window.innerWidth >= 1024">

        <!-- Overlay (mobile) -->
        <div x-show="sidebarOpen" x-cloak @click="sidebarOpen = false" class="fixed inset-0 bg-black/40 z-30 lg:hidden">
        </div>

        <!-- Sidebar (melayang, bisa diciutkan) -->
        <aside :class="[sidebarOpen ? 'translate-x-0' : '-translate-x-[130%]', collapsed ? 'w-20' : 'w-64']"
            class="fixed left-4 top-4 bottom-4 z-40 rounded-[28px] bg-brand text-white flex flex-col
                   shadow-[0_10px_30px_rgba(10,92,168,0.35)] ring-1 ring-white/20
                   transition-[width,transform] duration-200 ease-in-out lg:translate-x-0">

            {{-- Logo + tombol ciutkan (di DALAM card) --}}
            <div class="h-20 shrink-0 flex items-center" :class="collapsed ? 'justify-center' : 'pl-5 pr-3 gap-3'">
                <div class="w-11 h-11 shrink-0 rounded-xl bg-white flex items-center justify-center shadow-sm">
                    <img alt="Logo SOLID" src="{{ asset('assets/img/logo/logo.png') }}"
                        class="w-8 h-8 object-contain" />
                </div>
                <div x-show="!collapsed" class="leading-tight min-w-0 flex-1">
                    <p class="text-sm font-bold">SOLID</p>
                    <p class="text-[11px] text-white/70 truncate">Dinas Sosial Kota Bogor</p>
                </div>

                {{-- Sidebar lebar: tombol ciutkan di kanan logo (hanya layar besar) --}}
                <button type="button" x-show="!collapsed" @click="toggleSidebar()" title="Ciutkan sidebar"
                    class="hidden lg:flex w-8 h-8 shrink-0 rounded-lg items-center justify-center text-white/80 hover:bg-white/15 hover:text-white transition-colors">
                    <span class="material-symbols-outlined text-[20px]">chevron_left</span>
                </button>
            </div>

            {{-- Sidebar ciut: tombol lebarkan tepat di bawah logo --}}
            <button type="button" x-show="collapsed" x-cloak @click="toggleSidebar()" title="Lebarkan sidebar"
                class="flex w-12 h-8 mx-auto mb-1 shrink-0 rounded-lg items-center justify-center text-white/80 hover:bg-white/15 hover:text-white transition-colors">
                <span class="material-symbols-outlined text-[20px]">chevron_right</span>
            </button>

            {{-- ========== MENU (dibangun dari $menuItems di atas) ==========
                 - Sidebar lebar : folder membuka ke bawah (accordion bertingkat)
                 - Sidebar ciut  : isi folder muncul sebagai panel melayang di samping ikon
                                   (position: fixed, acuannya <aside>, jadi tidak terpotong
                                   oleh overflow nav)
                 - Nav SELALU bisa di-scroll vertikal agar ikon tidak tumpah keluar card
                 - Class `sidebar-scroll` memunculkan scrollbar tipis (lihat <style> di atas)
                 - Separator     : label grup (Front End / Modul / Data Master) saat lebar, garis tipis saat ciut --}}
            {{-- Pembungkus nav + indikator scroll:
                 - up/down   : true jika masih ada menu tersembunyi di atas/bawah
                 - check()   : dihitung ulang saat scroll, resize, accordion dibuka/ditutup,
                               atau sidebar diciutkan/dilebarkan --}}
            <div class="relative flex-1 min-h-0" x-data="{
                up: false,
                down: false,
                check() {
                    const n = this.$refs.nav;
                    if (!n) return;
                    this.up = n.scrollTop > 4;
                    this.down = n.scrollTop + n.clientHeight < n.scrollHeight - 4;
                }
            }"
                x-init="$nextTick(() => check());
                new ResizeObserver(() => check()).observe($refs.nav);
                new MutationObserver(() => $nextTick(() => check())).observe($refs.nav, { childList: true, subtree: true, attributes: true });
                $watch('collapsed', () => setTimeout(() => check(), 250));"
                @resize.window="check()">

            <nav x-ref="nav" @scroll.passive="check()"
                class="sidebar-scroll h-full px-3 pt-2 pb-12 space-y-1.5 overflow-y-auto overflow-x-hidden">
                @foreach ($menuItems as $top)
                    @if (isset($top['separator']))
                        {{-- Pemisah grup menu --}}
                        <div class="pt-2">
                            <div class="mx-3 border-t border-white/15"></div>
                            <p x-show="!collapsed"
                                class="px-3 pt-2 pb-0.5 text-[10px] font-bold uppercase tracking-[0.14em] text-white/50">
                                {{ $top['separator'] }}
                            </p>
                        </div>
                        @continue
                    @endif

                    @php $isAct = $active($top); @endphp

                    @if (!isset($top['children']))
                        {{-- Menu tunggal (link langsung) --}}
                        <a href="{{ route($top['route']) }}" :title="collapsed ? '{{ $top['label'] }}' : null"
                            :class="collapsed ? 'w-12 mx-auto justify-center' : 'w-full px-3 gap-3'"
                            class="h-12 rounded-xl flex items-center transition-colors
                                {{ $isAct ? 'bg-white/25 text-white shadow-inner' : 'text-white/80 hover:bg-white/15 hover:text-white' }}">
                            <span class="material-symbols-outlined text-[24px] shrink-0">{{ $top['icon'] }}</span>
                            <span x-show="!collapsed" class="text-sm font-medium truncate">{{ $top['label'] }}</span>
                        </a>
                    @else
                        {{-- Folder (PFM, Dayasos, Perlinsos, Rehabsos, Ground Check, Master Kriteria, Menu Frontend) --}}
                        <div class="relative" x-data="{ open: false, top: 0, maxH: 400 }"
                            x-init="open = {{ $isAct ? 'true' : 'false' }} && !collapsed;
                            $watch('collapsed', function(v) { open = v ? false : {{ $isAct ? 'true' : 'false' }}; })"
                            @click.outside="if (collapsed) open = false">

                            <button
                                @click="
                                    if (collapsed) {
                                        const r = $el.getBoundingClientRect();
                                        const a = $el.closest('aside').getBoundingClientRect();
                                        top = r.top - a.top;
                                        maxH = window.innerHeight - r.top - 16;
                                    }
                                    open = !open
                                "
                                type="button" :title="collapsed ? '{{ $top['label'] }}' : null"
                                :class="collapsed ? 'w-12 mx-auto justify-center' : 'w-full px-3 gap-3'"
                                class="h-12 rounded-xl flex items-center transition-colors
                                    {{ $isAct ? 'bg-white/25 text-white shadow-inner' : 'text-white/80 hover:bg-white/15 hover:text-white' }}">
                                <span class="material-symbols-outlined text-[24px] shrink-0">{{ $top['icon'] }}</span>
                                <span x-show="!collapsed"
                                    class="flex-1 text-left text-sm font-medium truncate">{{ $top['label'] }}</span>
                                <span x-show="!collapsed"
                                    class="material-symbols-outlined text-[18px] transition-transform"
                                    :class="open ? 'rotate-180' : ''">expand_more</span>
                            </button>

                            {{-- Accordion (sidebar lebar) --}}
                            <div x-show="open && !collapsed" x-cloak
                                x-transition:enter="transition ease-out duration-150"
                                x-transition:enter-start="opacity-0 -translate-y-1"
                                x-transition:enter-end="opacity-100 translate-y-0"
                                class="mt-1 ml-6 pl-4 border-l border-white/20 space-y-0.5">
                                {!! $renderChildren($top['children'], false) !!}
                            </div>

                            {{-- Panel melayang (sidebar ciut).
                                 `fixed` + <aside> ber-transform => posisinya mengacu ke aside,
                                 sehingga top dihitung relatif terhadap aside (lihat @click tombol di atas).
                                 Class `sidebar-scroll-light` = scrollbar tipis untuk latar putih. --}}
                            <div x-show="open && collapsed" x-cloak
                                :style="`top:${top}px; max-height:${maxH}px`"
                                x-transition:enter="transition ease-out duration-150"
                                x-transition:enter-start="opacity-0 -translate-x-1"
                                x-transition:enter-end="opacity-100 translate-x-0"
                                class="sidebar-scroll-light fixed left-full ml-5 w-64 overflow-y-auto bg-white text-on-surface rounded-2xl shadow-xl border border-outline-variant/30 p-2 z-50">
                                <p class="px-3 py-1.5 text-xs font-bold text-brand">{{ $top['label'] }}</p>
                                {!! $renderChildren($top['children'], true) !!}
                            </div>
                        </div>
                    @endif
                @endforeach
            </nav>

                {{-- Indikator: masih ada menu di ATAS (muncul setelah di-scroll ke bawah) --}}
                <div x-show="up" x-cloak x-transition.opacity
                    class="pointer-events-none absolute top-0 inset-x-0 h-8 bg-gradient-to-b from-brand to-transparent z-10">
                </div>

                {{-- Indikator: masih ada menu di BAWAH (pudar + panah naik-turun, bisa diklik) --}}
                <div x-show="down" x-cloak x-transition.opacity
                    class="pointer-events-none absolute bottom-0 inset-x-0 h-14 bg-gradient-to-t from-brand via-brand/90 to-transparent z-10 flex items-end justify-center pb-1.5">
                    <button type="button" @click="$refs.nav.scrollBy({ top: 220, behavior: 'smooth' })"
                        title="Scroll untuk melihat menu lainnya"
                        class="pointer-events-auto w-7 h-7 rounded-full bg-white/25 hover:bg-white/40 text-white flex items-center justify-center animate-bounce transition-colors">
                        <span class="material-symbols-outlined text-[20px]">keyboard_arrow_down</span>
                    </button>
                </div>
            </div>

            {{-- Logout (bagian bawah sidebar) --}}
            <form method="POST" action="{{ route('logout') }}" class="px-3 py-4 shrink-0">
                @csrf
                <button type="submit" :title="collapsed ? 'Logout' : null"
                    :class="collapsed ? 'w-12 mx-auto justify-center' : 'w-full px-3 gap-3'"
                    class="h-12 rounded-xl flex items-center text-white/80 hover:bg-white/15 hover:text-white transition-colors">
                    <span class="material-symbols-outlined text-[24px] shrink-0">logout</span>
                    <span x-show="!collapsed" class="text-sm font-medium">Logout</span>
                </button>
            </form>
        </aside>

        <!-- Spacer agar konten tidak ketutup sidebar fixed di layar besar (lebarnya ikut sidebar) -->
        <div class="hidden lg:block shrink-0 transition-[width] duration-200"
            :class="collapsed ? 'w-28' : 'w-[18rem]'"></div>

        <!-- Main -->
        <div class="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">

            <!-- Topbar -->
            <header class="shrink-0 flex items-center gap-4 pl-4 pr-6 pt-4 pb-2 lg:pl-6 lg:pr-8">
                <button @click="sidebarOpen = true"
                    class="lg:hidden w-11 h-11 shrink-0 rounded-xl bg-brand text-white flex items-center justify-center">
                    <span class="material-symbols-outlined">menu</span>
                </button>

                <h1 class="hidden md:block shrink-0 text-xl font-extrabold text-brand tracking-tight">
                    @yield('page_title', 'Beranda')
                </h1>

                {{-- Bar biru: pencarian + notifikasi + bantuan + pengguna --}}
                <div
                    class="ml-auto min-w-0 max-w-full h-14 rounded-xl bg-brand shadow-[0_6px_18px_rgba(10,92,168,0.30)] ring-1 ring-white/20 flex items-center gap-3 px-3 sm:px-5">

                    <div class="flex min-w-0">
                        <label
                            class="w-40 sm:w-56 max-w-full h-9 rounded-lg bg-surface-container-low flex items-center gap-2 px-3 shadow-inner">
                            <span class="material-symbols-outlined text-[18px] text-on-surface-variant">search</span>
                            <input type="text" placeholder="Cari data, ajuan, atau dokumen..."
                                class="w-full min-w-0 bg-transparent border-0 outline-none text-xs text-on-surface placeholder:text-on-surface-variant/70 focus:ring-0" />
                        </label>
                    </div>

                    <button type="button" title="Notifikasi"
                        class="hidden sm:flex w-8 h-8 shrink-0 items-center justify-center text-white/90 hover:text-white">
                        <span class="material-symbols-outlined text-[20px]">notifications</span>
                    </button>
                    <span class="hidden sm:flex w-8 h-8 shrink-0 items-center justify-center text-white/90"
                        title="Bantuan">
                        <span class="material-symbols-outlined text-[20px]">help</span>
                    </span>

                    {{-- ===== Dropdown user + Edit Profil (pop-up, tidak lewat halaman Kelola Akses) ===== --}}
                    <div class="shrink-0" x-data="{ userMenuOpen: false, profileModalOpen: {{ $errors->profil->any() ? 'true' : 'false' }} }">
                        <div class="relative">
                            <button @click="userMenuOpen = !userMenuOpen" @click.outside="userMenuOpen = false"
                                class="flex items-center gap-3 pl-1 rounded-lg transition-colors">
                                <div class="hidden sm:block leading-tight text-right">
                                    <p class="text-xs font-semibold text-white">
                                        {{ auth()->user()->name ?? 'Admin' }}</p>
                                    <p class="text-[10px] uppercase tracking-wide text-white/70">
                                        {{ auth()->user()->username ?? '' }}</p>
                                </div>
                                <div
                                    class="w-9 h-9 rounded-full bg-secondary-container ring-2 ring-white/70 flex items-center justify-center text-on-secondary-container font-semibold text-sm shrink-0">
                                    {{ strtoupper(substr(auth()->user()->name ?? 'A', 0, 1)) }}
                                </div>
                            </button>

                            <div x-show="userMenuOpen" x-cloak x-transition:enter="transition ease-out duration-100"
                                x-transition:enter-start="opacity-0 scale-95"
                                x-transition:enter-end="opacity-100 scale-100"
                                class="absolute right-0 mt-3 w-52 bg-surface-container-lowest text-on-surface border border-outline-variant/40 rounded-xl shadow-lg overflow-hidden z-50">

                                <button type="button" @click="profileModalOpen = true; userMenuOpen = false"
                                    class="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-on-surface hover:bg-surface-container transition-colors">
                                    <span class="material-symbols-outlined text-[18px]">person</span>
                                    Edit Profil
                                </button>

                                <div class="border-t border-outline-variant/40"></div>

                                <form method="POST" action="{{ route('logout') }}">
                                    @csrf
                                    <button type="submit"
                                        class="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-error hover:bg-error-container/40 transition-colors">
                                        <span class="material-symbols-outlined text-[18px]">logout</span>
                                        Logout
                                    </button>
                                </form>
                            </div>
                        </div>

                        {{-- Modal Edit Profil (akun milik pengguna yang sedang login) --}}
                        <div x-show="profileModalOpen" x-cloak
                            class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
                            <div @click.outside="profileModalOpen = false"
                                x-transition:enter="transition ease-out duration-150"
                                x-transition:enter-start="opacity-0 scale-95"
                                x-transition:enter-end="opacity-100 scale-100"
                                class="bg-surface-container-lowest w-full max-w-md rounded-xl shadow-lg overflow-hidden">

                                <div
                                    class="flex items-center justify-between px-5 py-4 border-b border-outline-variant/40">
                                    <h3 class="text-base font-semibold text-on-surface">Edit Profil</h3>
                                    <button @click="profileModalOpen = false" class="text-on-surface-variant">
                                        <span class="material-symbols-outlined">close</span>
                                    </button>
                                </div>

                                <form method="POST" action="{{ route('profil.update') }}" class="p-5 space-y-4">
                                    @csrf
                                    @method('PUT')

                                    <div>
                                        <label class="block text-sm font-medium mb-1">Username</label>
                                        <input name="username" type="text"
                                            value="{{ old('username', auth()->user()->username ?? '') }}"
                                            class="w-full rounded-lg border border-outline-variant/50 px-3 py-2 text-sm"
                                            required />
                                        @error('username', 'profil')
                                            <p class="text-xs text-error mt-1">{{ $message }}</p>
                                        @enderror
                                    </div>

                                    <div>
                                        <label class="block text-sm font-medium mb-1">Email</label>
                                        <input name="email" type="email"
                                            value="{{ old('email', auth()->user()->email ?? '') }}"
                                            class="w-full rounded-lg border border-outline-variant/50 px-3 py-2 text-sm"
                                            required />
                                        @error('email', 'profil')
                                            <p class="text-xs text-error mt-1">{{ $message }}</p>
                                        @enderror
                                    </div>

                                    <div>
                                        <label class="block text-sm font-medium mb-1">Kata Sandi Baru</label>
                                        <p class="text-xs text-red-600 font-medium mb-1">Kosongkan jika tidak ingin
                                            mengubah
                                            kata sandi.</p>
                                        <div class="relative" x-data="{ show: false }">
                                            <input name="password" :type="show ? 'text' : 'password'"
                                                class="w-full rounded-lg border border-outline-variant/50 px-3 py-2 pr-10 text-sm" />
                                            <button type="button" @click="show = !show" tabindex="-1"
                                                class="absolute inset-y-0 right-0 flex items-center px-3 text-on-surface-variant"
                                                :aria-label="show ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'">
                                                <span class="material-symbols-outlined text-[16px]"
                                                    x-text="show ? 'visibility_off' : 'visibility'"></span>
                                            </button>
                                        </div>
                                        @error('password', 'profil')
                                            <p class="text-xs text-error mt-1">{{ $message }}</p>
                                        @enderror
                                    </div>

                                    <div>
                                        <label class="block text-sm font-medium mb-1">Konfirmasi Kata Sandi
                                            Baru</label>
                                        <div class="relative" x-data="{ show: false }">
                                            <input name="password_confirmation" :type="show ? 'text' : 'password'"
                                                class="w-full rounded-lg border border-outline-variant/50 px-3 py-2 pr-10 text-sm" />
                                            <button type="button" @click="show = !show" tabindex="-1"
                                                class="absolute inset-y-0 right-0 flex items-center px-3 text-on-surface-variant"
                                                :aria-label="show ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'">
                                                <span class="material-symbols-outlined text-[16px]"
                                                    x-text="show ? 'visibility_off' : 'visibility'"></span>
                                            </button>
                                        </div>
                                    </div>

                                    <div class="flex justify-end gap-2 pt-2">
                                        <button type="button" @click="profileModalOpen = false"
                                            class="px-4 py-2 rounded-lg text-sm border border-outline-variant/50">Batal</button>
                                        <button type="submit"
                                            class="px-4 py-2 rounded-lg text-sm bg-primary text-on-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Content -->
            <main class="flex-1 overflow-y-auto pl-4 pr-6 pb-24 pt-2 lg:pl-6 lg:pr-8">
                @if (session('success'))
                    <div class="mb-4 px-4 py-3 rounded-lg bg-success-container text-on-success-container text-sm">
                        {{ session('success') }}
                    </div>
                @endif
                @if (session('error'))
                    <div class="mb-4 px-4 py-3 rounded-lg bg-error-container text-on-error-container text-sm">
                        {{ session('error') }}
                    </div>
                @endif
                @yield('content')
            </main>
        </div>
    </div>

    {{-- ====== Tombol bantuan mengambang (floating) + modal Flipbook PDF ====== --}}
    <div x-data="{ helpOpen: false }">

        <button type="button" @click="helpOpen = true" title="Bantuan / Panduan Penggunaan"
            class="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-primary text-on-primary shadow-lg
                   hover:bg-secondary transition-all flex items-center justify-center">
            <span class="material-symbols-outlined text-[26px]">help</span>
        </button>

        <div x-show="helpOpen" x-cloak x-init="$watch('helpOpen', value => { if (value) window.dispatchEvent(new CustomEvent('help-flipbook-open')); })" @keydown.escape.window="helpOpen = false"
            x-transition:enter="transition ease-out duration-150" x-transition:enter-start="opacity-0"
            x-transition:enter-end="opacity-100" class="fixed inset-0 z-[9990] bg-[#101418] overflow-hidden">

            {{-- Header — bar tipis tembus pandang, melayang di atas buku
                 (absolute, tidak mereservasi ruang lewat padding) supaya
                 area buku di bawahnya bisa penuh setinggi layar. --}}
            <div
                class="absolute top-0 left-0 right-0 flex items-center justify-between px-4 py-2 gap-3 bg-white/85 backdrop-blur z-30 shadow-sm">
                <h3 class="text-sm font-bold text-on-surface flex items-center gap-2 min-w-0">
                    <span class="material-symbols-outlined text-[20px] text-primary shrink-0">menu_book</span>
                    <span class="truncate">Panduan Penggunaan</span>
                </h3>
                <div class="flex items-center gap-1 shrink-0">
                    <a href="{{ $helpPdfUrl }}" target="_blank" rel="noopener noreferrer"
                        title="Buka di Tab Baru"
                        class="w-8 h-8 rounded-full flex items-center justify-center text-primary hover:bg-primary/10 transition-colors">
                        <span class="material-symbols-outlined text-[18px]">open_in_new</span>
                    </a>
                    <a href="{{ $helpPdfUrl }}" download="Panduan-Penggunaan-SOLID.pdf" title="Unduh PDF"
                        class="w-8 h-8 rounded-full flex items-center justify-center text-primary hover:bg-primary/10 transition-colors">
                        <span class="material-symbols-outlined text-[20px]">cloud_download</span>
                    </a>
                    <div class="w-px h-5 bg-outline-variant/40 mx-1"></div>
                    <button @click="helpOpen = false" title="Tutup (Esc)"
                        class="w-8 h-8 rounded-full flex items-center justify-center text-error hover:bg-error-container/50 transition-colors">
                        <span class="material-symbols-outlined text-[20px]">close</span>
                    </button>
                </div>
            </div>

            {{-- Container Flipbook — full-bleed, memakai hampir seluruh layar.
                 Header & kontrol di bawah melayang TEMBUS PANDANG di atasnya
                 (bukan mendorong/mengecilkan area buku), jadi bukunya bisa
                 setinggi & sebesar mungkin. --}}
            <div class="absolute inset-0 w-full h-full flex items-center justify-center p-2">

                <div id="help-flipbook-loading"
                    class="absolute inset-0 flex flex-col items-center justify-center gap-3 text-on-surface-variant z-10 bg-[#eef1f6]">
                    <span
                        class="material-symbols-outlined text-[32px] animate-spin text-primary">progress_activity</span>
                    <span class="text-sm font-medium">Memuat Panduan...</span>
                </div>

                <div id="help-flipbook-wrap" class="w-full h-full flex items-center justify-center px-2">
                    <div id="help-flipbook" class="hidden shadow-2xl"></div>
                </div>

                {{-- Kontrol Navigasi + Pencarian (Absolute di bagian bawah) --}}
                <div id="help-flipbook-controls"
                    class="hidden absolute bottom-2 left-1/2 -translate-x-1/2 z-20 flex-col sm:flex-row items-center gap-2 sm:gap-3 bg-white/90 backdrop-blur px-3 py-1.5 rounded-2xl sm:rounded-full shadow-lg border border-outline-variant/30 max-w-[92%] w-max">


                    {{-- Pencarian --}}
                    <div class="flex items-center gap-1.5">
                        <input type="text" id="help-flipbook-search-input" placeholder="Cari kata..."
                            class="w-28 sm:w-40 text-xs px-2.5 py-1.5 rounded-full border border-outline-variant/50 focus:outline-none focus:ring-1 focus:ring-primary" />
                        <button type="button" id="help-flipbook-search-btn"
                            class="w-7 h-7 shrink-0 rounded-full bg-primary text-white flex items-center justify-center hover:bg-secondary transition-colors">
                            <span class="material-symbols-outlined text-[16px]">search</span>
                        </button>
                        <span id="help-flipbook-search-status"
                            class="text-[11px] text-on-surface-variant whitespace-nowrap"></span>
                    </div>

                    <div class="hidden sm:block w-px h-5 bg-outline-variant/40"></div>

                    {{-- Navigasi halaman --}}
                    <div class="flex items-center gap-3">
                        <button type="button" id="help-flipbook-prev"
                            class="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center hover:bg-primary hover:text-white transition-all">
                            <span class="material-symbols-outlined text-[20px]">chevron_left</span>
                        </button>
                        <span class="flex items-center gap-1 text-xs font-bold text-on-surface-variant tabular-nums">
                            <input type="number" id="help-flipbook-page-input" min="1" value="1"
                                class="w-10 text-center rounded-md border border-outline-variant/50 px-1 py-0.5 text-xs focus:outline-none focus:ring-1 focus:ring-primary" />
                            <span>/ <span id="help-flipbook-page-total">0</span></span>
                        </span>
                        <button type="button" id="help-flipbook-next"
                            class="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center hover:bg-primary hover:text-white transition-all">
                            <span class="material-symbols-outlined text-[20px]">chevron_right</span>
                        </button>
                    </div>

                    <span id="help-flipbook-load-progress"
                        class="text-[11px] text-success font-medium whitespace-nowrap"></span>
                </div>

                <p id="help-flipbook-error"
                    class="hidden absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-sm text-error text-center bg-error-container px-6 py-4 rounded-xl shadow-lg border border-error/20 max-w-sm z-30">
                    Gagal memuat file panduan. Pastikan file PDF tersedia dan perangkat memiliki cukup memori.
                </p>
            </div>
        </div>
    </div>
    {{-- ====== Akhir tombol bantuan & modal flipbook ====== --}}

    {{-- Kotak highlight hasil pencarian pada flipbook. Diletakkan di level
         body supaya `position: fixed`-nya selalu mengacu ke viewport, aman
         dari elemen ancestor mana pun yang mungkin memakai transform. --}}
    <div id="help-flipbook-search-highlight"
        class="hidden fixed pointer-events-none border-2 border-yellow-400 bg-yellow-300/40 rounded shadow-[0_0_10px_rgba(250,204,21,0.75)] z-[9995]">
    </div>


    {{-- pdf.js: merender tiap halaman PDF ke <canvas> lalu dikonversi ke gambar --}}
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
    {{-- page-flip: efek membalik halaman seperti buku, dari gambar yang sudah dirender --}}
    <script src="https://cdn.jsdelivr.net/npm/page-flip@2.0.7/dist/js/page-flip.browser.js"></script>

    {{-- ====== Modal konfirmasi bertema (menggantikan confirm() bawaan browser) ====== --}}
    <div id="app-confirm-modal"
        class="hidden fixed inset-0 z-[9999] flex items-center justify-center bg-black/40 backdrop-blur-[1px] px-4">
        <div data-confirm-panel
            class="opacity-0 scale-95 transition-all duration-150 ease-out bg-surface-container-lowest border border-outline-variant/40 rounded-xl shadow-xl w-full max-w-sm p-5">
            <div class="flex items-start gap-3">
                <span data-confirm-icon class="material-symbols-outlined text-[22px] text-primary">help</span>
                <div class="flex-1 min-w-0">
                    <h3 data-confirm-title class="text-sm font-semibold text-on-surface">Konfirmasi</h3>
                    <p data-confirm-message class="text-sm text-on-surface-variant mt-1"></p>
                </div>
            </div>
            <div class="flex justify-end gap-2 mt-5">
                <button type="button" data-confirm-cancel
                    class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-outline-variant/60 text-on-surface hover:bg-surface-container text-sm font-medium transition-colors">
                    Batal
                </button>
                <button type="button" data-confirm-ok
                    class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-on-primary hover:bg-secondary text-sm font-medium transition-colors">
                    Ya, Lanjutkan
                </button>
            </div>
        </div>
    </div>

    <script>
        (function() {
            let modalEl, titleEl, messageEl, confirmBtn, cancelBtn, iconEl, panelEl;
            let resolvePromise = null;

            function ensureModal() {
                if (modalEl) return true;
                modalEl = document.getElementById('app-confirm-modal');
                if (!modalEl) return false;

                panelEl = modalEl.querySelector('[data-confirm-panel]');
                titleEl = modalEl.querySelector('[data-confirm-title]');
                messageEl = modalEl.querySelector('[data-confirm-message]');
                confirmBtn = modalEl.querySelector('[data-confirm-ok]');
                cancelBtn = modalEl.querySelector('[data-confirm-cancel]');
                iconEl = modalEl.querySelector('[data-confirm-icon]');

                confirmBtn.addEventListener('click', () => close(true));
                cancelBtn.addEventListener('click', () => close(false));
                modalEl.addEventListener('click', (e) => {
                    if (e.target === modalEl) close(false);
                });
                document.addEventListener('keydown', (e) => {
                    if (!modalEl.classList.contains('hidden') && e.key === 'Escape') close(false);
                });

                return true;
            }

            function open(message, options) {
                options = options || {};
                if (!ensureModal()) {
                    return Promise.resolve(window.confirm(message));
                }

                const title = options.title || 'Konfirmasi';
                const variant = options.variant || 'primary';
                const confirmText = options.confirmText || 'Ya, Lanjutkan';
                const cancelText = options.cancelText || 'Batal';

                titleEl.textContent = title;
                messageEl.textContent = message;
                confirmBtn.textContent = confirmText;
                cancelBtn.textContent = cancelText;

                confirmBtn.className = variant === 'error' ?
                    'inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-error text-on-error hover:opacity-90 text-sm font-medium transition-colors' :
                    'inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-on-primary hover:bg-secondary text-sm font-medium transition-colors';

                iconEl.textContent = variant === 'error' ? 'warning' : 'help';
                iconEl.className = 'material-symbols-outlined text-[22px] ' + (variant === 'error' ? 'text-error' :
                    'text-primary');

                modalEl.classList.remove('hidden');
                requestAnimationFrame(() => {
                    panelEl.classList.remove('opacity-0', 'scale-95');
                });

                return new Promise((resolve) => {
                    resolvePromise = resolve;
                });
            }

            function close(result) {
                if (!modalEl) return;
                panelEl.classList.add('opacity-0', 'scale-95');
                setTimeout(() => modalEl.classList.add('hidden'), 150);
                if (resolvePromise) {
                    resolvePromise(result);
                    resolvePromise = null;
                }
            }

            window.confirmModal = open;

            document.addEventListener('click', async function(e) {
                const trigger = e.target.closest('[data-confirm]');
                if (!trigger || trigger.dataset.confirmBound === 'pending') return;

                e.preventDefault();

                const ok = await window.confirmModal(trigger.getAttribute('data-confirm'), {
                    variant: trigger.getAttribute('data-confirm-variant') || 'primary',
                    title: trigger.getAttribute('data-confirm-title') || undefined,
                });
                if (!ok) return;

                trigger.dataset.confirmBound = 'pending';

                const form = trigger.closest('form');
                if (form) {
                    if (trigger.tagName === 'BUTTON' && trigger.name) {
                        const hidden = document.createElement('input');
                        hidden.type = 'hidden';
                        hidden.name = trigger.name;
                        hidden.value = trigger.value;
                        form.appendChild(hidden);
                    }
                    form.submit();
                } else if (trigger.tagName === 'A' && trigger.href) {
                    window.location.href = trigger.href;
                }

                delete trigger.dataset.confirmBound;
            });
        })();
    </script>
    {{-- ====== Akhir blok modal konfirmasi ====== --}}

    {{-- ====== Flipbook PDF untuk tombol bantuan (pdf.js + page-flip) ======
         Dirapikan seperti contoh viewer manual-book: rendering per-halaman
         bertahap (tidak memblokir modal), navigasi lewat input nomor halaman,
         indikator progres pemuatan, dan pencarian kata dengan highlight. --}}
    <script>
        (function() {
            const PDF_URL = @json($helpPdfUrl);

            let loaded = false;
            let loading = false;
            let pageFlipInstance = null;
            let pdfDocRef = null;
            let totalPages = 0;
            let loadedCount = 0;
            let renderScale = 2; // nilai awal, dihitung ulang secara dinamis di initFlipbook()

            let pageImages = [];
            let pageTexts = [];
            let pageItemsData = [];

            let currentMatches = [];
            let currentMatchPos = -1;
            let lastQuery = null;

            function createPlaceholder(w, h) {
                const c = document.createElement('canvas');
                c.width = w;
                c.height = h;
                const ctx = c.getContext('2d');
                ctx.fillStyle = '#eef1f6';
                ctx.fillRect(0, 0, w, h);
                ctx.fillStyle = '#9aa5b1';
                ctx.font = '16px sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('Memuat halaman...', w / 2, h / 2);
                return c.toDataURL('image/jpeg', 0.7);
            }

            function renderSinglePage(pageNum) {
                return pdfDocRef.getPage(pageNum).then(function(page) {
                    const vp = page.getViewport({
                        scale: renderScale
                    });
                    const canvas = document.createElement('canvas');
                    canvas.width = vp.width;
                    canvas.height = vp.height;
                    const ctx = canvas.getContext('2d');

                    const renderTask = page.render({
                        canvasContext: ctx,
                        viewport: vp
                    }).promise;
                    const textTask = page.getTextContent().then(function(tc) {
                        pageTexts[pageNum - 1] = tc.items.map(function(it) {
                            return it.str;
                        }).join(' ').toLowerCase();
                        pageItemsData[pageNum - 1] = {
                            items: tc.items,
                            viewport: vp
                        };
                    });

                    return Promise.all([renderTask, textTask]).then(function() {
                        return canvas.toDataURL('image/jpeg', 0.85);
                    });
                });
            }

            function updatePageIndicator() {
                const input = document.getElementById('help-flipbook-page-input');
                if (!pageFlipInstance || !input) return;
                input.value = pageFlipInstance.getCurrentPageIndex() + 1;
            }

            function updateLoadProgress() {
                const el = document.getElementById('help-flipbook-load-progress');
                if (!el) return;
                el.textContent = loadedCount >= totalPages ? '' : ('Memuat: ' + loadedCount + '/' + totalPages);
            }

            function hideSearchHighlight() {
                const hl = document.getElementById('help-flipbook-search-highlight');
                if (!hl) return;
                clearTimeout(hl._fadeTimer);
                hl.classList.add('hidden');
            }

            function showSearchHighlight(pageIndex, rect, retriesLeft) {
                if (retriesLeft === undefined) retriesLeft = 8;
                const flipbookEl = document.getElementById('help-flipbook');
                const targetSrc = pageImages[pageIndex];
                const imgs = flipbookEl.querySelectorAll('img');
                let targetImg = null,
                    bestArea = 0;

                imgs.forEach(function(img) {
                    if (img.src === targetSrc) {
                        const r = img.getBoundingClientRect();
                        const area = r.width * r.height;
                        if (area > bestArea) {
                            bestArea = area;
                            targetImg = img;
                        }
                    }
                });

                if (!targetImg || bestArea === 0) {
                    if (retriesLeft <= 0) return;
                    setTimeout(function() {
                        showSearchHighlight(pageIndex, rect, retriesLeft - 1);
                    }, 200);
                    return;
                }

                const ir = targetImg.getBoundingClientRect();
                const scaleX = ir.width / rect.canvasWidth;
                const scaleY = ir.height / rect.canvasHeight;
                const hl = document.getElementById('help-flipbook-search-highlight');
                clearTimeout(hl._fadeTimer);
                hl.style.left = (ir.left + rect.left * scaleX) + 'px';
                hl.style.top = (ir.top + rect.top * scaleY) + 'px';
                hl.style.width = (rect.width * scaleX) + 'px';
                hl.style.height = (rect.height * scaleY) + 'px';
                hl.classList.remove('hidden');
                hl.style.opacity = '1';
            }

            function findAllMatches(query) {
                const matches = [];
                for (let p = 0; p < pageItemsData.length; p++) {
                    const data = pageItemsData[p];
                    if (!data) continue;
                    for (let i = 0; i < data.items.length; i++) {
                        const it = data.items[i];
                        if (it.str && it.str.toLowerCase().indexOf(query) !== -1) {
                            const tx = pdfjsLib.Util.transform(data.viewport.transform, it.transform);
                            const fontHeight = Math.hypot(tx[2], tx[3]) || 12;
                            const fontWidth = Math.hypot(tx[0], tx[1]) || 1;
                            const width = (it.width || it.str.length * 5) * fontWidth;
                            matches.push({
                                pageIndex: p,
                                rect: {
                                    left: tx[4],
                                    top: tx[5] - fontHeight,
                                    width: width,
                                    height: fontHeight * 1.3,
                                    canvasWidth: data.viewport.width,
                                    canvasHeight: data.viewport.height
                                }
                            });
                        }
                    }
                }
                return matches;
            }

            function goToMatch(idx) {
                if (!currentMatches.length) return;
                if (idx < 0) idx = currentMatches.length - 1;
                if (idx >= currentMatches.length) idx = 0;
                currentMatchPos = idx;
                const match = currentMatches[idx];
                const statusEl = document.getElementById('help-flipbook-search-status');
                if (statusEl) {
                    statusEl.textContent = (idx + 1) + '/' + currentMatches.length + ' (hal. ' + (match.pageIndex + 1) +
                        ')';
                }
                hideSearchHighlight();
                pageFlipInstance.flip(match.pageIndex);
                setTimeout(function() {
                    showSearchHighlight(match.pageIndex, match.rect);
                }, 450);
            }

            function doSearch() {
                const input = document.getElementById('help-flipbook-search-input');
                const statusEl = document.getElementById('help-flipbook-search-status');
                if (!input || !pageFlipInstance) return;
                const query = input.value.trim().toLowerCase();

                if (query !== lastQuery) {
                    hideSearchHighlight();
                    lastQuery = query;

                    if (!query) {
                        if (statusEl) statusEl.textContent = '';
                        currentMatches = [];
                        currentMatchPos = -1;
                        return;
                    }

                    currentMatches = findAllMatches(query);
                    currentMatchPos = -1;

                    if (!currentMatches.length) {
                        if (statusEl) {
                            statusEl.textContent = loadedCount < totalPages ?
                                'Tidak ditemukan (masih memuat...)' :
                                'Tidak ditemukan';
                        }
                        return;
                    }

                    goToMatch(0);
                    return;
                }

                if (!currentMatches.length) {
                    if (statusEl) statusEl.textContent = 'Tidak ditemukan';
                    return;
                }
                goToMatch(currentMatchPos + 1);
            }

            function loadRemainingPagesInBackground() {
                const CONCURRENCY = 3;
                let nextPage = 2;
                let activeCount = 0;
                let updateScheduled = false;

                updateLoadProgress();

                function scheduleFlipbookUpdate() {
                    if (updateScheduled) return;
                    updateScheduled = true;
                    setTimeout(function() {
                        updateScheduled = false;
                        if (pageFlipInstance && typeof pageFlipInstance.updateFromImages === 'function') {
                            pageFlipInstance.updateFromImages(pageImages);
                        }
                    }, 250);
                }

                function startNext() {
                    while (activeCount < CONCURRENCY && nextPage <= totalPages) {
                        (function(pn) {
                            activeCount++;
                            renderSinglePage(pn)
                                .then(function(url) {
                                    pageImages[pn - 1] = url;
                                })
                                .catch(function(e) {
                                    console.error('Gagal merender halaman ' + pn, e);
                                })
                                .then(function() {
                                    loadedCount++;
                                    activeCount--;
                                    updateLoadProgress();
                                    scheduleFlipbookUpdate();
                                    startNext();
                                });
                        })(nextPage);
                        nextPage++;
                    }
                }

                startNext();
            }

            async function initFlipbook() {
                if (loaded || loading) return;
                loading = true;

                const loadingEl = document.getElementById('help-flipbook-loading');
                const flipbookEl = document.getElementById('help-flipbook');
                const controlsEl = document.getElementById('help-flipbook-controls');
                const errorEl = document.getElementById('help-flipbook-error');
                const wrapEl = document.getElementById('help-flipbook-wrap');

                try {
                    if (typeof pdfjsLib === 'undefined') throw new Error('pdf.js gagal dimuat');
                    pdfjsLib.GlobalWorkerOptions.workerSrc =
                        'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

                    pdfDocRef = await pdfjsLib.getDocument(PDF_URL).promise;
                    totalPages = pdfDocRef.numPages;
                    if (!totalPages) throw new Error('PDF tidak memiliki halaman');

                    // Dapatkan rasio dasar PDF dari halaman 1
                    const firstPage = await pdfDocRef.getPage(1);
                    const viewportRaw = firstPage.getViewport({
                        scale: 1
                    });
                    const baseWidth = viewportRaw.width;
                    const baseHeight = viewportRaw.height;

                    // Hitung ukuran TAMPIL buku dulu (berdasarkan ruang modal yang
                    // tersedia), sebelum merender halaman apa pun. Ini penting:
                    // skala render PDF di bawah diturunkan dari ukuran tampil ini,
                    // supaya resolusi gambar selalu cukup tinggi untuk ukuran
                    // sebesar apa pun buku ini ditampilkan (termasuk saat full-bleed
                    // di layar besar) — kalau urutannya dibalik, gambar hasil render
                    // beresolusi tetap akan di-upscale oleh browser untuk memenuhi
                    // ukuran tampil yang lebih besar, dan itulah yang bikin teksnya
                    // buram.
                    function computeSpreadSize() {
                        const rect = wrapEl.getBoundingClientRect();
                        const availW = Math.max(rect.width - 8, 280);
                        const availH = Math.max(rect.height - 8, 360);

                        const spreadRatio = (baseWidth * 2) / baseHeight;

                        let spreadW = availW;
                        let spreadH = spreadW / spreadRatio;

                        if (spreadH > availH) {
                            spreadH = availH;
                            spreadW = spreadH * spreadRatio;
                        }

                        return {
                            pageW: Math.max(Math.round(spreadW / 2), 140),
                            pageH: Math.max(Math.round(spreadH), 200),
                        };
                    }

                    const {
                        pageW,
                        pageH
                    } = computeSpreadSize();

                    // Turunkan skala render PDF dari ukuran tampil x devicePixelRatio
                    // (supaya tajam di layar retina/HiDPI juga), dibatasi 1x–3x agar
                    // memori & waktu render tetap wajar untuk PDF yang panjang.
                    const dpr = window.devicePixelRatio || 1;
                    renderScale = Math.min(Math.max((pageW * dpr) / baseWidth, 1.2), 3);

                    const placeholderVp = firstPage.getViewport({
                        scale: renderScale
                    });
                    pageImages = new Array(totalPages).fill(createPlaceholder(placeholderVp.width, placeholderVp
                        .height));

                    // Render halaman pertama dulu (dengan skala yang sudah pas)
                    // supaya buku bisa langsung tampil, sisanya dimuat bertahap di
                    // latar belakang (lihat di bawah).
                    pageImages[0] = await renderSinglePage(1);
                    loadedCount = 1;

                    pageFlipInstance = new St.PageFlip(flipbookEl, {
                        width: pageW,
                        height: pageH,
                        size: 'stretch',
                        minWidth: Math.round(pageW * 0.5),
                        maxWidth: pageW,
                        minHeight: Math.round(pageH * 0.5),
                        maxHeight: pageH,
                        showCover: true,
                        maxShadowOpacity: 0.25,
                        showPageCorners: true,
                        mobileScrollSupport: true,
                    });

                    pageFlipInstance.loadFromImages(pageImages);
                    pageFlipInstance.on('flip', function() {
                        updatePageIndicator();
                        hideSearchHighlight();
                    });

                    document.getElementById('help-flipbook-prev').addEventListener('click', function() {
                        hideSearchHighlight();
                        pageFlipInstance.flipPrev();
                    });
                    document.getElementById('help-flipbook-next').addEventListener('click', function() {
                        hideSearchHighlight();
                        pageFlipInstance.flipNext();
                    });

                    // Navigasi lewat input nomor halaman
                    const pageInputEl = document.getElementById('help-flipbook-page-input');
                    const pageTotalEl = document.getElementById('help-flipbook-page-total');
                    pageInputEl.max = totalPages;
                    pageTotalEl.textContent = totalPages;

                    function goToPage() {
                        let t = parseInt(pageInputEl.value, 10);
                        if (isNaN(t)) return;
                        t = Math.max(1, Math.min(t, totalPages));
                        pageInputEl.value = t;
                        hideSearchHighlight();
                        pageFlipInstance.flip(t - 1);
                    }
                    pageInputEl.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            goToPage();
                        }
                    });
                    pageInputEl.addEventListener('blur', goToPage);

                    // Pencarian kata
                    document.getElementById('help-flipbook-search-btn').addEventListener('click', doSearch);
                    const searchInputEl = document.getElementById('help-flipbook-search-input');
                    searchInputEl.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            doSearch();
                        }
                    });
                    searchInputEl.addEventListener('input', function() {
                        lastQuery = null;
                    });

                    // Navigasi keyboard (dinonaktifkan saat sedang mengetik di input)
                    document.addEventListener('keydown', function(e) {
                        if (!pageFlipInstance) return;
                        if (!flipbookEl || flipbookEl.classList.contains('hidden')) return;
                        const active = document.activeElement;
                        if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA')) return;
                        if (e.key === 'ArrowLeft') pageFlipInstance.flipPrev();
                        if (e.key === 'ArrowRight') pageFlipInstance.flipNext();
                    });

                    // Hitung ulang & terapkan ukuran saat jendela/modal berganti ukuran,
                    // supaya buku tetap proporsional di layar apa pun.
                    let resizeTimeout = null;
                    window.addEventListener('resize', function() {
                        if (!pageFlipInstance) return;
                        clearTimeout(resizeTimeout);
                        resizeTimeout = setTimeout(function() {
                            if (typeof pageFlipInstance.updateSize === 'function') {
                                pageFlipInstance.updateSize();
                            }
                            hideSearchHighlight();
                        }, 150);
                    });

                    loadingEl.classList.add('hidden');
                    flipbookEl.classList.remove('hidden');
                    controlsEl.classList.remove('hidden');
                    controlsEl.classList.add('flex'); // munculkan kontrol melayang

                    updatePageIndicator();
                    loaded = true;

                    // Muat sisa halaman secara bertahap di latar belakang, tidak
                    // memblokir tampilan buku yang sudah bisa dibuka dari halaman 1.
                    loadRemainingPagesInBackground();
                } catch (err) {
                    console.error('Gagal memuat flipbook panduan:', err);
                    loadingEl.classList.add('hidden');
                    errorEl.classList.remove('hidden');
                } finally {
                    loading = false;
                }
            }

            window.addEventListener('help-flipbook-open', initFlipbook);
        })();
    </script>
    {{-- ====== Akhir blok flipbook PDF ====== --}}

    @stack('scripts')
</body>

</html>
