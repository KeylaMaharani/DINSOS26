<?php

namespace Database\Seeders;

use App\Models\GcKriteriaParameter;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Tambahan field Ground Check untuk DATABASE YANG SUDAH TERISI
 * (GcKriteriaSeeder dilewati bila master sudah ada).
 *
 * Aman dijalankan berulang: field yang sudah ada (kelompok + nama sama) DILEWATI,
 * jadi hasil edit Super Admin di menu master tidak tertimpa.
 *
 * Catatan Faskes: bertipe 'pilihan' TANPA opsi di tabel. Pilihannya otomatis dari
 * config/faskes.php (sesuai kecamatan pemohon), lihat MasyarakatController::labelOpsi().
 *
 * Jalankan: php artisan db:seed --class=GcKriteriaTambahanSeeder
 */
class GcKriteriaTambahanSeeder extends Seeder
{
    private const KELOMPOK_VALID = [
        'kependudukan', 'pendidikan', 'ketenagakerjaan', 'kesehatan',
        'keluarga', 'aset_bergerak', 'aset_tidak_bergerak', 'dokumentasi',
    ];

    private const TIPE_VALID = [
        'pilihan', 'pilihan_ganda', 'teks', 'angka', 'tanggal', 'koordinat', 'foto',
    ];

    public function run(): void
    {
        // Format: [kelompok, nama, bobot, tipe_input, wajib, opsi (opsional)]
        $tambahan = [
            ['kesehatan',   'Diagnosa',                      0, 'teks',    true],
            ['kesehatan',   'Faskes (fasilitas kesehatan)',  0, 'pilihan', true], // opsi dari config/faskes.php
            ['kesehatan',   'Surat Keterangan Rawat Inap',   0, 'foto',    false],
            ['dokumentasi', 'Foto kartu keluarga',           2, 'foto',    true],
            ['dokumentasi', 'Foto KTP',                      2, 'foto',    true],
        ];

        DB::transaction(function () use ($tambahan) {
            $urutan = (int) GcKriteriaParameter::max('urutan');

            foreach ($tambahan as $row) {
                [$kelompok, $nama, $bobot, $tipe, $wajib] = $row;
                $opsi = $row[5] ?? [];

                if (! in_array($kelompok, self::KELOMPOK_VALID, true)) {
                    $this->command?->error("Kelompok '{$kelompok}' tidak valid, '{$nama}' dilewati.");
                    continue;
                }

                if (! in_array($tipe, self::TIPE_VALID, true)) {
                    $this->command?->error("Tipe '{$tipe}' tidak valid, '{$nama}' dilewati.");
                    continue;
                }

                if (GcKriteriaParameter::where('kelompok', $kelompok)->where('nama', $nama)->exists()) {
                    $this->command?->line("Sudah ada, dilewati: {$nama}");
                    continue;
                }

                $keterangan = null;
                if (stripos($nama, 'faskes') !== false && $tipe === 'pilihan') {
                    $keterangan = 'Pilihan Puskesmas mengikuti kecamatan pemohon (config/faskes.php).';
                } elseif ($opsi && in_array($tipe, ['pilihan', 'pilihan_ganda'], true)) {
                    $keterangan = 'Opsi sementara, nilai belum ditentukan.';
                }

                $param = GcKriteriaParameter::create([
                    'kelompok' => $kelompok,
                    'urutan' => ++$urutan,
                    'nama' => $nama,
                    'bobot' => $bobot,
                    'tipe_input' => $tipe,
                    'sumber' => null,
                    'pbi_parameter_id' => null,
                    'keterangan' => $keterangan,
                    'aktif' => true,
                    'wajib' => $wajib,
                ]);

                if ($param->butuhOpsi()) {
                    foreach ($opsi as $j => $label) {
                        $param->opsis()->updateOrCreate(
                            ['label' => $label],
                            ['nilai' => null, 'urutan' => $j + 1]
                        );
                    }
                }

                $this->command?->info("Ditambahkan: {$nama}");
            }
        });
    }
}