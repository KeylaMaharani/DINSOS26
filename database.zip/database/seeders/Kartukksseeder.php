<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use App\Models\KartuKksPermohonan;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class KartuKksSeeder extends Seeder
{
    /**
     * Wilayah kelurahan untuk user demo role "kelurahan" (akun lama).
     * Harus SAMA PERSIS dengan kolom `kelurahan` di data permohonan,
     * karena daftar Ajuan & detail untuk role Kelurahan dibatasi per wilayah.
     */
    private const KELURAHAN_DEMO = 'Sempur';

    public function run(): void
    {
        // 1) Pastikan semua role di alur sudah ada (aman dijalankan berkali-kali)
        $roles = [
            ['name' => 'Kelurahan', 'slug' => 'kelurahan'],
            ['name' => 'Operator Dinsos', 'slug' => 'operator_dinsos'],
            ['name' => 'PFM', 'slug' => 'pfm'],
            ['name' => 'Dayasos', 'slug' => 'dayasos'],
            ['name' => 'Perlinsos', 'slug' => 'perlinsos'],
            ['name' => 'Rehabsos', 'slug' => 'rehabsos'],
            ['name' => 'Kabin (Kepala Bidang)', 'slug' => 'kabin'],
            ['name' => 'Kadis (Kepala Dinas)', 'slug' => 'kadis'],
        ];

        foreach ($roles as $r) {
            Role::firstOrCreate(['slug' => $r['slug']], $r);
        }

        // 2) Contoh 1 user dummy per role, supaya bisa login & lihat sisi masing-masing
        //    Password default: password
        foreach ($roles as $r) {
            User::firstOrCreate(
                ['email' => $r['slug'] . '@dinsoskotabogor.test'],
                [
                    'name' => $r['name'],
                    'username' => $r['slug'],
                    'password' => Hash::make('password'),
                    'role_id' => Role::where('slug', $r['slug'])->first()->id,
                    'kelurahan' => $r['slug'] === 'kelurahan' ? self::KELURAHAN_DEMO : null,
                ]
            );
        }

        // firstOrCreate() tidak mengubah user yang SUDAH ada, jadi untuk user
        // "kelurahan" lama yang belum punya wilayah, isi di sini (aman diulang).
        User::where('username', 'kelurahan')
            ->whereNull('kelurahan')
            ->update(['kelurahan' => self::KELURAHAN_DEMO]);

        // 3) Dummy permohonan tersebar di berbagai tahap alur, supaya tiap tab
        //    (Ajuan/Arsip/Monitoring) sudah ada isinya waktu pertama kali dicoba.
        //
        //    PENTING: current_role_id harus sesuai siapa yang SEDANG memegang
        //    berkas pada status tsb (lihat transitions() di KartuKksController):
        //      diajukan          -> operator_dinsos  (input ajuan)
        //      diproses_kabin    -> kabin            (cek Kepala Bidang)
        //      disetujui_kadis   -> kadis            (approval + TTD digital)
        //      validasi_dinsos   -> operator_dinsos  (memberitahu pemohon)
        //      selesai / ditolak -> null
        $dinsosRole = Role::where('slug', 'operator_dinsos')->first();
        $kabinRole = Role::where('slug', 'kabin')->first();
        $kadisRole = Role::where('slug', 'kadis')->first();

        $dummy = [
            [
                'nik' => '3271010101900001',
                'nama' => 'Sri Wahyuni',
                'alamat' => 'Jl. Merdeka No. 12, Kel. Sempur',
                'lat' => -6.5950, 'lng' => 106.7890,
                'masalah' => 'Kartu Hilang',
                'status' => KartuKksPermohonan::STATUS_DIAJUKAN,
                'current_role' => $dinsosRole?->id,
            ],
            [
                'nik' => '3271011101900011',
                'nama' => 'Yayan Sopian',
                'alamat' => 'Jl. Otista No. 5, Kel. Sempur',
                'lat' => -6.5940, 'lng' => 106.7955,
                'masalah' => 'Data Tidak Sesuai KTP',
                'status' => KartuKksPermohonan::STATUS_DIAJUKAN,
                'current_role' => $dinsosRole?->id,
            ],
            [
                'nik' => '3271020202880002',
                'nama' => 'Ahmad Fauzi',
                'alamat' => 'Jl. Pajajaran No. 45, Kel. Baranangsiang',
                'lat' => -6.6021, 'lng' => 106.8071,
                'masalah' => 'Kartu Rusak',
                'status' => KartuKksPermohonan::STATUS_DIPROSES_KABIN,
                'current_role' => $kabinRole?->id,
            ],
            [
                'nik' => '3271030303950003',
                'nama' => 'Dewi Lestari',
                'alamat' => 'Jl. Sudirman No. 8, Kel. Cibogor',
                'lat' => -6.5975, 'lng' => 106.7950,
                'masalah' => 'Kartu Hilang',
                'status' => KartuKksPermohonan::STATUS_DISETUJUI_KADIS,
                'current_role' => $kadisRole?->id,
            ],
            [
                'nik' => '3271040404870004',
                'nama' => 'Budi Santoso',
                'alamat' => 'Jl. Ahmad Yani No. 20, Kel. Tanah Sareal',
                'lat' => -6.5721, 'lng' => 106.7959,
                'masalah' => 'Kartu Rusak',
                'status' => KartuKksPermohonan::STATUS_VALIDASI_DINSOS,
                'current_role' => $dinsosRole?->id,
            ],
            [
                'nik' => '3271041404870014',
                'nama' => 'Fitri Ramadhani',
                'alamat' => 'Jl. Salak No. 9, Kel. Babakan',
                'lat' => -6.6005, 'lng' => 106.8002,
                'masalah' => 'Kartu Hilang',
                'status' => KartuKksPermohonan::STATUS_DIPROSES_KABIN,
                'current_role' => $kabinRole?->id,
            ],
            [
                'nik' => '3271050505920005',
                'nama' => 'Ratna Sari',
                'alamat' => 'Jl. Pahlawan No. 3, Kel. Empang',
                'lat' => -6.6100, 'lng' => 106.7930,
                'masalah' => 'Kartu Hilang',
                'status' => KartuKksPermohonan::STATUS_SELESAI,
                'current_role' => null,
            ],
            [
                'nik' => '3271060606930006',
                'nama' => 'Hendra Gunawan',
                'alamat' => 'Jl. Raya Tajur No. 15, Kel. Baranangsiang',
                'lat' => -6.6180, 'lng' => 106.8100,
                'masalah' => 'Data Tidak Sesuai KTP',
                'status' => KartuKksPermohonan::STATUS_DITOLAK,
                'current_role' => null,
            ],
        ];

        // Pemetaan nilai "masalah" di permohonan -> nilai dropdown "Masalah Kartu"
        // di form Data Detail (harus sama dengan aturan `in:` di updateDetail()),
        // supaya data demo bisa disimpan ulang tanpa gagal validasi.
        $masalahKartuDetail = [
            'Kartu Hilang' => 'hilang',
            'Kartu Rusak' => 'rusak',
            'Data Tidak Sesuai KTP' => 'nama tidak sesuai',
        ];

        // Tahap yang sudah melewati persetujuan Kadis (surat keterangan sudah ada)
        $sudahDisetujuiKadis = [
            KartuKksPermohonan::STATUS_VALIDASI_DINSOS,
            KartuKksPermohonan::STATUS_SELESAI,
        ];

        foreach ($dummy as $d) {
            $permohonan = KartuKksPermohonan::firstOrCreate(
                ['nik' => $d['nik']],
                [
                    'nama_pemohon' => $d['nama'],
                    'alamat' => $d['alamat'],
                    'latitude' => $d['lat'],
                    'longitude' => $d['lng'],
                    'masalah_kartu' => $d['masalah'],
                    'nomor_kehilangan_polisi' => $d['masalah'] === 'Kartu Hilang' ? 'SKH/' . rand(100, 999) . '/IX/2026' : null,
                    'status' => $d['status'],
                    'current_role_id' => $d['current_role'],
                    'kelurahan' => explode(', Kel. ', $d['alamat'])[1] ?? null,
                    'tanggal_insert' => now()->subDays(rand(1, 20)),
                ]
            );

            if ($permohonan->wasRecentlyCreated) {
                $permohonan->detail()->create([
                    'nik' => $d['nik'],
                    'nama' => $d['nama'],
                    // Nilai disesuaikan dengan opsi dropdown di form Data Detail
                    'jenis_kelamin' => rand(0, 1) ? 'Laki-laki' : 'Perempuan',
                    'tempat_lahir' => 'Bogor',
                    'tanggal_lahir' => now()->subYears(rand(25, 55))->subDays(rand(1, 300)),
                    'agama' => 'Islam',
                    'status_perkawinan' => 'Kawin',
                    'no_pkh' => 'PKH-' . rand(100000, 999999),
                    'no_kk' => '32710' . rand(1000000000, 2000000000),
                    'no_kartu_kks' => 'KKS-' . rand(100000, 999999),
                    'no_rekening' => rand(1000000000, 9999999999),
                    'pekerjaan' => 'Tidak Bekerja',
                    'alamat' => $d['alamat'],
                    'masalah_kartu' => $masalahKartuDetail[$d['masalah']] ?? 'keterangan lainnya',
                    'nomor_kehilangan_polisi' => $permohonan->nomor_kehilangan_polisi,
                ]);

                // Path dummy -- ganti dengan file asli setelah upload beneran berjalan
                $permohonan->lampiran()->create([
                    'scan_ktp' => 'dummy/ktp-placeholder.jpg',
                    'scan_kartu_keluarga' => 'dummy/kk-placeholder.jpg',
                    'surat_kehilangan_polisi' => $d['masalah'] === 'Kartu Hilang' ? 'dummy/skh-placeholder.pdf' : null,
                    'scan_kartu_kks' => 'dummy/kks-placeholder.jpg',
                    'screenshot_dtsen' => 'dummy/dtsen-placeholder.jpg',
                ]);

                // Surat pengantar kelurahan tidak dipakai lagi di alur baru.
                // Surat keterangan Dinsos baru ada setelah Kadis menyetujui.
                $permohonan->surat()->create([
                    'surat_pengantar_kelurahan' => null,
                    'surat_keterangan_dinsos' => in_array($d['status'], $sudahDisetujuiKadis, true)
                        ? 'dummy/surat-keterangan-placeholder.pdf' : null,
                ]);

                // Bangun histori log sesuai posisi status saat ini.
                // Urutan key = urutan tahap alur baru. Tiap entri adalah aktivitas
                // yang membuat berkas SAMPAI di status tsb (cocok dengan task_lanjut
                // di transitions() KartuKksController).
                $steps = [
                    KartuKksPermohonan::STATUS_DIAJUKAN => [
                        'task' => 'Ajuan Diinput Operator',
                        'rolename' => 'Operator Dinsos',
                        'username' => 'operator_dinsos',
                    ],
                    KartuKksPermohonan::STATUS_DIPROSES_KABIN => [
                        'task' => 'Diteruskan ke Kabid',
                        'rolename' => 'Operator Dinsos',
                        'username' => 'operator_dinsos',
                    ],
                    KartuKksPermohonan::STATUS_DISETUJUI_KADIS => [
                        'task' => 'Disetujui Kabid, diteruskan ke Kadis',
                        'rolename' => 'Kepala Bidang',
                        'username' => 'kabin',
                    ],
                    KartuKksPermohonan::STATUS_VALIDASI_DINSOS => [
                        // Harus sama dengan KartuKksController::TASK_TTD_KADIS
                        'task' => 'Disetujui Kadis (TTD Digital)',
                        'rolename' => 'Kepala Dinas',
                        'username' => 'kadis',
                    ],
                    KartuKksPermohonan::STATUS_SELESAI => [
                        'task' => 'Hasil Diberitahukan ke Pemohon',
                        'rolename' => 'Operator Dinsos',
                        'username' => 'operator_dinsos',
                    ],
                ];

                if ($d['status'] === KartuKksPermohonan::STATUS_DITOLAK) {
                    // Untuk yang ditolak: log 1 tahap awal saja, lalu log "Ditolak" oleh Kabid
                    $permohonan->logs()->create([
                        'tanggal_proses' => now()->subDays(rand(5, 20)),
                        'username' => 'operator_dinsos',
                        'taskname' => 'Ajuan Diinput Operator',
                        'rolename' => 'Operator Dinsos',
                        'catatan' => 'Data awal diinput operator dari pemohon yang datang langsung.',
                    ]);
                    $permohonan->logs()->create([
                        'tanggal_proses' => now()->subDays(rand(1, 4)),
                        'username' => 'kabin',
                        'taskname' => 'Ditolak',
                        'rolename' => 'Kepala Bidang',
                        'catatan' => 'NIK tidak sesuai dengan data KTP.',
                    ]);
                } else {
                    $order = array_keys($steps);
                    $currentIndex = array_search($d['status'], $order, true);
                    $totalSteps = $currentIndex + 1;
                    $i = 0;
                    foreach ($steps as $status => $step) {
                        if ($i > $currentIndex) {
                            break;
                        }
                        // Log terlama = paling banyak hari lalu, log terbaru = paling sedikit hari lalu,
                        // supaya urutan tanggal selalu naik (kronologis), bukan acak.
                        $daysAgo = ($totalSteps - $i) * rand(2, 5);
                        $permohonan->logs()->create([
                            'tanggal_proses' => now()->subDays($daysAgo),
                            'username' => $step['username'],
                            'taskname' => $step['task'],
                            'rolename' => $step['rolename'],
                            'catatan' => $i === 0 ? 'Data awal diinput operator dari pemohon yang datang langsung.' : null,
                        ]);
                        $i++;
                    }
                }
            }
        }
    }
}