<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('dtsen_permohonan', function (Blueprint $table) {
            $table->id();

            // Data inti yang selalu tampil di listing (Arsip & Monitoring)
            $table->string('nik', 20);
            $table->string('nama_pemohon');
            $table->text('alamat')->nullable();

            // "Alasan Cetak" -> kolom listing Monitoring & filter di Arsip
            // (setara peran "masalah_kartu" di modul Kartu KKS)
            $table->string('alasan_cetak')->nullable();

            // Status alur (dipakai oleh Ajuan, Arsip, dan Monitoring)
            // diajukan -> verifikasi_kelurahan -> ttd_lurah -> validasi_dinsos
            // -> diproses_kabin -> disetujui_kadis -> selesai
            // (atau) ditolak di titik manapun
            $table->string('status')->default('diajukan');

            // Role yang sedang memegang berkas ini sekarang (untuk notifikasi & filter "punya siapa")
            $table->foreignId('current_role_id')->nullable()
                ->constrained('roles')->nullOnDelete();

            // Kelurahan asal pemohon (opsional, isi manual dulu selama belum ada master wilayah)
            $table->string('kelurahan')->nullable();

            $table->date('tanggal_insert')->default(DB::raw('(CURDATE())'));
            $table->foreignId('created_by')->nullable()
                ->constrained('users')->nullOnDelete();

            $table->timestamps();

            $table->index(['status']);
            $table->index(['alasan_cetak']);
            $table->index(['tanggal_insert']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('dtsen_permohonan');
    }
};
