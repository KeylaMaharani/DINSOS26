<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('kartu_kks_permohonan', function (Blueprint $table) {
            $table->foreignId('user_id')->nullable()->after('id')
                ->constrained('users')->nullOnDelete();
        });

        Schema::table('dtsen_permohonan', function (Blueprint $table) {
            $table->foreignId('user_id')->nullable()->after('id')
                ->constrained('users')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('kartu_kks_permohonan', function (Blueprint $table) {
            $table->dropConstrainedForeignId('user_id');
        });
        Schema::table('dtsen_permohonan', function (Blueprint $table) {
            $table->dropConstrainedForeignId('user_id');
        });
    }
};
